# Vicinity - Proximity-Based Dating App

A revolutionary dating app that replaces swiping with real-world serendipity. Vicinity matches compatible users within 500 meters using BLE + GPS, auto-schedules dates via Google Calendar, and secures contact exchange with AES-256 encryption.

## Architecture Overview

```
┌─────────────┐     BLE/GPS     ┌─────────────────┐
│  Mobile App │◄───────────────►│  Node.js API    │
│  (Expo/RN)  │    WebSocket    │  (Express)      │
└──────┬──────┘                 └────────┬────────┘
       │                                 │
       │    Google OAuth/Calendar       │
       └─────────────────────────────────┘
       │                                 │
┌──────┴──────┐              ┌──────────┴──────────┐
│ PostgreSQL  │              │ Redis (Geo + TTL)   │
│ (Prisma)    │              │                     │
└─────────────┘              └─────────────────────┘
```

## Project Structure

```
vicinity/
├── backend/                 # Node.js API
│   ├── src/
│   │   ├── modules/
│   │   │   ├── auth/       # Africa's Talking OTP + Google OAuth
│   │   │   ├── proximity/  # BLE + GPS matchmaking
│   │   │   ├── match/      # Match lifecycle management
│   │   │   ├── scheduler/  # Calendar + Places auto-scheduler
│   │   │   ├── wallet/     # AES-256 encrypted contact exchange
│   │   │   └── notification/ # FCM/APNs + Wearable haptics
│   │   ├── middleware/     # Auth, rate limiting, validation
│   │   ├── lib/            # Prisma, Google APIs, crypto utils
│   │   └── websocket/      # Socket.io real-time events
│   ├── prisma/
│   │   └── schema.prisma   # Complete database schema
│   └── docker-compose.yml  # Local development stack
│
└── mobile/                  # React Native (Expo)
    ├── src/
    │   ├── screens/        # Auth, Home, Spark, Date, Wallet
    │   ├── hooks/          # BLE, Location, Encryption, Smartwatch
    │   ├── services/       # BLE, Location, Crypto, Notifications
    │   ├── context/        # Auth + Match state management
    │   └── navigation/     # React Navigation setup
    └── app.json            # Expo config with BLE/Location permissions
```

## Quick Start

### Backend

```bash
cd backend
cp .env.example .env
# Edit .env with your API keys

docker-compose up -d  # Starts Postgres + Redis
npm install
npx prisma migrate dev
npm run dev
```

### Mobile

```bash
cd mobile
npm install
npx expo start
# Scan QR code with Expo Go app
```

## Environment Variables

### Backend (.env)

| Variable | Description |
|----------|-------------|
| `DATABASE_URL` | PostgreSQL connection string |
| `REDIS_URL` | Redis connection string |
| `AT_API_KEY` | Africa's Talking API key |
| `GOOGLE_CLIENT_ID` | Google OAuth client ID |
| `GOOGLE_CLIENT_SECRET` | Google OAuth client secret |
| `JWT_SECRET` | JWT signing secret (min 32 chars) |
| `WALLET_MASTER_KEY` | AES-256 master key (base64) |

### Mobile (.env)

| Variable | Description |
|----------|-------------|
| `EXPO_PUBLIC_API_URL` | Backend API base URL |

## API Endpoints

### Authentication
- `POST /api/v1/auth/otp/request` - Request SMS OTP
- `POST /api/v1/auth/otp/verify` - Verify OTP and login
- `POST /api/v1/auth/refresh` - Refresh access token
- `GET /api/v1/auth/google/url` - Get Google OAuth URL

### Proximity
- `POST /api/v1/proximity/report` - Report location + BLE scan

### Matches
- `GET /api/v1/matches/active` - Get active matches
- `POST /api/v1/matches/consent` - Give match consent
- `POST /api/v1/matches/schedule` - Schedule date

### Scheduler
- `POST /api/v1/scheduler/suggest` - Generate date suggestions
- `POST /api/v1/scheduler/select` - Select date suggestion

### Wallet
- `POST /api/v1/wallet` - Create encrypted wallet
- `POST /api/v1/wallet/exchange` - Exchange ECDH keys
- `GET /api/v1/wallet/:matchId` - Get wallet contents

## Security

- **AES-256-GCM** encryption for Match Wallet
- **ECDH key exchange** for secure contact sharing
- **JWT + Redis sessions** for authentication
- **Rate limiting** on all auth endpoints
- **ZKP Geohash** for privacy-preserving proximity
- **BLE rotating UUIDs** to prevent tracking

## Tech Stack

| Layer | Technology |
|-------|-----------|
| Mobile | React Native (Expo), TypeScript |
| Backend | Node.js, Express, TypeScript |
| Database | PostgreSQL (Prisma ORM) |
| Cache | Redis (Geospatial + TTL) |
| Auth | Africa's Talking OTP, Google OAuth 2.0 |
| Push | Firebase Cloud Messaging, APNs |
| BLE | react-native-ble-plx |
| Maps | Google Places API |
| Calendar | Google Calendar API |

## License

MIT
