import AfricasTalking from 'africastalking';
import { env } from '../config/env';
import { RedisSessionService } from '../services/redis.service';

const at = AfricasTalking({
  apiKey: env.AT_API_KEY,
  username: env.AT_USERNAME,
});

const sms = at.SMS;

export class AfricaTalkingService {
  /**
   * Send OTP via Africa's Talking SMS Gateway
   */
  static async sendOtp(phoneNumber: string, otp: string): Promise<void> {
    const message = `Your Vicinity verification code is: ${otp}. Valid for 5 minutes. Do not share this code.`;

    try {
      const response = await sms.send({
        to: [phoneNumber],
        message,
        from: env.AT_SENDER_ID || undefined,
      });

      const result = response.SMSMessageData.Recipients[0];
      if (result.statusCode !== 101 && result.statusCode !== 100) {
        throw new Error(`SMS failed: ${result.status}`);
      }
    } catch (error: any) {
      console.error('Africa's Talking SMS Error:', error);
      // Fallback: log OTP in dev mode
      if (env.NODE_ENV === 'development') {
        console.log(`[DEV OTP] ${phoneNumber}: ${otp}`);
      } else {
        throw new Error('Failed to send OTP');
      }
    }
  }

  /**
   * Generate cryptographically secure 6-digit OTP
   */
  static generateOtp(): string {
    const array = new Uint32Array(1);
    crypto.getRandomValues(array);
    return String(array[0] % 900000 + 100000);
  }
}
