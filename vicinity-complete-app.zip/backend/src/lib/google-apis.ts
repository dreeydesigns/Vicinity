import { google, calendar_v3, Auth } from 'googleapis';
import { env } from '../config/env';
import { prisma } from './prisma';

const oauth2Client = new google.auth.OAuth2(
  env.GOOGLE_CLIENT_ID,
  env.GOOGLE_CLIENT_SECRET,
  env.GOOGLE_REDIRECT_URI
);

export class GoogleApiService {
  static getAuthUrl(state: string): string {
    return oauth2Client.generateAuthUrl({
      access_type: 'offline',
      prompt: 'consent',
      scope: [
        'https://www.googleapis.com/auth/userinfo.profile',
        'https://www.googleapis.com/auth/userinfo.email',
        'https://www.googleapis.com/auth/calendar.readonly',
        'https://www.googleapis.com/auth/calendar.freebusy',
        'https://www.googleapis.com/auth/drive.readonly',
      ],
      state,
    });
  }

  static async exchangeCode(code: string): Promise<{
    tokens: Auth.Credentials;
    profile: { id: string; email: string; name: string; picture?: string };
  }> {
    const { tokens } = await oauth2Client.getToken(code);
    oauth2Client.setCredentials(tokens);

    const oauth2 = google.oauth2({ version: 'v2', auth: oauth2Client });
    const { data } = await oauth2.userinfo.get();

    if (!data.id || !data.email) {
      throw new Error('Incomplete Google profile');
    }

    return {
      tokens,
      profile: {
        id: data.id,
        email: data.email,
        name: data.name || '',
        picture: data.picture || undefined,
      },
    };
  }

  static async refreshAccessToken(refreshToken: string): Promise<string> {
    oauth2Client.setCredentials({ refresh_token: refreshToken });
    const { credentials } = await oauth2Client.refreshAccessToken();
    return credentials.access_token!;
  }

  static async getCalendarClient(userId: string): Promise<calendar_v3.Calendar> {
    const user = await prisma.user.findUnique({
      where: { id: userId },
      select: { googleAccessToken: true, googleRefreshToken: true, googleTokenExpiry: true },
    });

    if (!user?.googleRefreshToken) {
      throw new Error('Google Calendar not connected');
    }

    let accessToken = user.googleAccessToken || '';

    if (user.googleTokenExpiry && new Date() >= user.googleTokenExpiry) {
      accessToken = await this.refreshAccessToken(user.googleRefreshToken);
      await prisma.user.update({
        where: { id: userId },
        data: {
          googleAccessToken: accessToken,
          googleTokenExpiry: new Date(Date.now() + 3600 * 1000),
        },
      });
    }

    oauth2Client.setCredentials({ access_token: accessToken });
    return google.calendar({ version: 'v3', auth: oauth2Client });
  }

  static async getFreeBusy(
    userId: string,
    timeMin: Date,
    timeMax: Date
  ): Promise<calendar_v3.Schema$FreeBusyResponse> {
    const calendar = await this.getCalendarClient(userId);
    const user = await prisma.user.findUnique({
      where: { id: userId },
      select: { googleEmail: true },
    });

    const response = await calendar.freebusy.query({
      requestBody: {
        timeMin: timeMin.toISOString(),
        timeMax: timeMax.toISOString(),
        items: [{ id: user?.googleEmail || 'primary' }],
      },
    });

    return response.data;
  }

  static async listEvents(
    userId: string,
    timeMin: Date,
    timeMax: Date
  ): Promise<calendar_v3.Schema$Event[]> {
    const calendar = await this.getCalendarClient(userId);
    const response = await calendar.events.list({
      calendarId: 'primary',
      timeMin: timeMin.toISOString(),
      timeMax: timeMax.toISOString(),
      singleEvents: true,
      orderBy: 'startTime',
      maxResults: 50,
    });
    return response.data.items || [];
  }
}
