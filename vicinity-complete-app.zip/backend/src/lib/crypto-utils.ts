import crypto from 'crypto';

const ALGORITHM = 'aes-256-gcm';
const KEY_LENGTH = 32;
const IV_LENGTH = 16;
const AUTH_TAG_LENGTH = 16;
const SALT_LENGTH = 32;

/**
 * Derive AES-256 key from password + salt using PBKDF2
 */
export function deriveKey(password: string, salt: Buffer): Buffer {
  return crypto.pbkdf2Sync(password, salt, 100000, KEY_LENGTH, 'sha256');
}

/**
 * Encrypt plaintext using AES-256-GCM
 * Returns: { encrypted, iv, authTag, salt }
 */
export function encryptAES(plaintext: string, password: string): {
  encrypted: string;
  iv: string;
  authTag: string;
  salt: string;
} {
  const salt = crypto.randomBytes(SALT_LENGTH);
  const iv = crypto.randomBytes(IV_LENGTH);
  const key = deriveKey(password, salt);

  const cipher = crypto.createCipheriv(ALGORITHM, key, iv);
  const encrypted = Buffer.concat([cipher.update(plaintext, 'utf8'), cipher.final()]);
  const authTag = cipher.getAuthTag();

  return {
    encrypted: Buffer.concat([encrypted]).toString('base64'),
    iv: iv.toString('hex'),
    authTag: authTag.toString('hex'),
    salt: salt.toString('hex'),
  };
}

/**
 * Decrypt AES-256-GCM ciphertext
 */
export function decryptAES(
  encrypted: string,
  iv: string,
  authTag: string,
  salt: string,
  password: string
): string {
  const key = deriveKey(password, Buffer.from(salt, 'hex'));
  const decipher = crypto.createDecipheriv(
    ALGORITHM,
    key,
    Buffer.from(iv, 'hex')
  );
  decipher.setAuthTag(Buffer.from(authTag, 'hex'));

  const decrypted = Buffer.concat([
    decipher.update(Buffer.from(encrypted, 'base64')),
    decipher.final(),
  ]);

  return decrypted.toString('utf8');
}

/**
 * Generate ECDH key pair (secp256k1) for wallet key exchange
 */
export function generateECDHKeyPair(): { privateKey: string; publicKey: string } {
  const ecdh = crypto.createECDH('secp256k1');
  ecdh.generateKeys();
  return {
    privateKey: ecdh.getPrivateKey('hex'),
    publicKey: ecdh.getPublicKey('hex', 'compressed'),
  };
}

/**
 * Compute shared secret from own private key + other party's public key
 */
export function computeSharedSecret(privateKey: string, publicKey: string): string {
  const ecdh = crypto.createECDH('secp256k1');
  ecdh.setPrivateKey(privateKey, 'hex');
  const secret = ecdh.computeSecret(publicKey, 'hex');
  return crypto.createHash('sha256').update(secret).digest('hex');
}

/**
 * Hash data with SHA-256
 */
export function sha256(data: string): string {
  return crypto.createHash('sha256').update(data).digest('hex');
}

/**
 * Constant-time comparison to prevent timing attacks
 */
export function secureCompare(a: string, b: string): boolean {
  const bufA = Buffer.from(a);
  const bufB = Buffer.from(b);
  if (bufA.length !== bufB.length) return false;
  return crypto.timingSafeEqual(bufA, bufB);
}
