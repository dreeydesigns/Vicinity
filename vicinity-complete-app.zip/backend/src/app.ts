import express from 'express';
import cors from 'cors';
import authRoutes from './modules/auth/auth.routes';
import userRoutes from './modules/user/user.routes';
import proximityRoutes from './modules/proximity/proximity.routes';
import matchRoutes from './modules/match/match.routes';
import schedulerRoutes from './modules/scheduler/scheduler.routes';
import walletRoutes from './modules/wallet/wallet.routes';
import { errorHandler } from './middleware/error-handler.middleware';

const app = express();

app.use(cors({
  origin: process.env.CLIENT_URL || '*',
  credentials: true,
}));
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true }));

// Health check
app.get('/health', (req, res) => {
  res.status(200).json({ status: 'ok', timestamp: new Date().toISOString() });
});

// API routes
app.use('/api/v1/auth', authRoutes);
app.use('/api/v1/users', userRoutes);
app.use('/api/v1/proximity', proximityRoutes);
app.use('/api/v1/matches', matchRoutes);
app.use('/api/v1/scheduler', schedulerRoutes);
app.use('/api/v1/wallet', walletRoutes);

// Error handler (must be last)
app.use(errorHandler);

export default app;
