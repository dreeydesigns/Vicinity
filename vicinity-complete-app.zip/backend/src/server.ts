import app from './app';
import { initRedis, closeRedis } from './services/redis.service';
import { prisma } from './lib/prisma';

const PORT = process.env.PORT || 3000;

const startServer = async () => {
  try {
    await initRedis();

    // Test database connection
    await prisma.$connect();
    console.log('Database connected');

    const server = app.listen(PORT, () => {
      console.log(`Vicinity API running on port ${PORT}`);
    });

    // Graceful shutdown
    const shutdown = async (signal: string) => {
      console.log(`${signal} received. Shutting down gracefully...`);
      server.close(async () => {
        await closeRedis();
        await prisma.$disconnect();
        console.log('Server closed');
        process.exit(0);
      });
    };

    process.on('SIGTERM', () => shutdown('SIGTERM'));
    process.on('SIGINT', () => shutdown('SIGINT'));
  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
};

startServer();
