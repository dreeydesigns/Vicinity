import { z } from 'zod';

const envSchema = z.object({
  NODE_ENV: z.enum(['development', 'production', 'test']).default('development'),
  PORT: z.string().default('3000'),
  DATABASE_URL: z.string().min(1),
  REDIS_URL: z.string().default('redis://localhost:6379'),
  AT_API_KEY: z.string().min(1),
  AT_USERNAME: z.string().default('sandbox'),
  AT_SENDER_ID: z.string().optional(),
  GOOGLE_CLIENT_ID: z.string().min(1),
  GOOGLE_CLIENT_SECRET: z.string().min(1),
  GOOGLE_REDIRECT_URI: z.string().min(1),
  GOOGLE_PLACES_API_KEY: z.string().optional(),
  JWT_SECRET: z.string().min(32),
  JWT_REFRESH_SECRET: z.string().min(32),
  WALLET_MASTER_KEY: z.string().min(32),
  FCM_SERVER_KEY: z.string().optional(),
  CLIENT_URL: z.string().optional(),
});

export const env = envSchema.parse(process.env);
