import { Request, Response, NextFunction } from 'express';
import jwt from 'jsonwebtoken';
import { env } from '../config/env';
import { RedisSessionService } from '../services/redis.service';

interface AuthRequest extends Request {
  user?: { id: string; phoneNumber: string };
}

export const authenticate = async (
  req: AuthRequest,
  res: Response,
  next: NextFunction
): Promise<void> => {
  try {
    const authHeader = req.headers.authorization;
    if (!authHeader?.startsWith('Bearer ')) {
      res.status(401).json({ error: 'Authorization header required' });
      return;
    }

    const token = authHeader.split(' ')[1];
    const decoded = jwt.verify(token, env.JWT_SECRET) as { sub: string; jti: string };

    // Check Redis session (token blacklisting support)
    const sessionUserId = await RedisSessionService.validateSession(decoded.jti);
    if (!sessionUserId || sessionUserId !== decoded.sub) {
      res.status(401).json({ error: 'Session expired or revoked' });
      return;
    }

    req.user = { id: decoded.sub, phoneNumber: '' };
    next();
  } catch (error) {
    res.status(401).json({ error: 'Invalid or expired token' });
  }
};
