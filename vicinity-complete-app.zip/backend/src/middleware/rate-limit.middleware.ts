import { Request, Response, NextFunction } from 'express';
import { RedisSessionService } from '../services/redis.service';

export const rateLimit = (prefix: string, maxRequests: number, windowSec: number) => {
  return async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const identifier = req.ip || 'unknown';
      const key = `${prefix}:${identifier}`;

      const allowed = await RedisSessionService.checkRateLimit(key, maxRequests, windowSec);
      if (!allowed) {
        res.status(429).json({
          error: 'Rate limit exceeded',
          retryAfter: windowSec,
        });
        return;
      }

      next();
    } catch (error) {
      next(error);
    }
  };
};
