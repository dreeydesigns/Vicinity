import { createClient, RedisClientType } from 'redis';

let redisClient: RedisClientType;

export const initRedis = async (): Promise<RedisClientType> => {
  redisClient = createClient({
    url: process.env.REDIS_URL || 'redis://localhost:6379',
    socket: {
      reconnectStrategy: (retries) => Math.min(retries * 50, 500),
    },
  });

  redisClient.on('error', (err) => console.error('Redis Client Error:', err));
  redisClient.on('connect', () => console.log('Redis connected'));

  await redisClient.connect();
  return redisClient;
};

export const getRedis = (): RedisClientType => {
  if (!redisClient) throw new Error('Redis not initialized');
  return redisClient;
};

export const closeRedis = async (): Promise<void> => {
  if (redisClient) await redisClient.quit();
};

const GEO_KEY = 'geo:active_users';
const USER_LOC_KEY = 'user:{userId}:location';
const OTP_KEY = 'otp:{phone}';
const SESSION_KEY = 'session:{token}';
const MATCH_EPHEMERAL = 'match:{matchId}:ephemeral';
const ACTIVE_MATCHES = 'user:{userId}:active_matches';
const BLE_PROXIMITY = 'ble:proximity:{userId}';
const RATE_LIMIT = 'ratelimit:{key}';
const CALENDAR_CACHE = 'calendar:{userId}:availability';

export class RedisSessionService {
  static async storeOtp(phoneNumber: string, otp: string, attemptCount: number = 0): Promise<void> {
    const redis = getRedis();
    const key = OTP_KEY.replace('{phone}', phoneNumber);
    await redis.setEx(key, 300, JSON.stringify({ otp, attempts: attemptCount, createdAt: Date.now() }));
  }

  static async getOtp(phoneNumber: string): Promise<{ otp: string; attempts: number } | null> {
    const redis = getRedis();
    const key = OTP_KEY.replace('{phone}', phoneNumber);
    const data = await redis.get(key);
    return data ? JSON.parse(data) : null;
  }

  static async incrementOtpAttempt(phoneNumber: string): Promise<void> {
    const redis = getRedis();
    const key = OTP_KEY.replace('{phone}', phoneNumber);
    const data = await redis.get(key);
    if (data) {
      const parsed = JSON.parse(data);
      parsed.attempts += 1;
      const ttl = await redis.ttl(key);
      await redis.setEx(key, Math.max(ttl, 1), JSON.stringify(parsed));
    }
  }

  static async deleteOtp(phoneNumber: string): Promise<void> {
    const redis = getRedis();
    await redis.del(OTP_KEY.replace('{phone}', phoneNumber));
  }

  static async storeSession(tokenJti: string, userId: string, expiresInSec: number): Promise<void> {
    const redis = getRedis();
    const key = SESSION_KEY.replace('{token}', tokenJti);
    await redis.setEx(key, expiresInSec, userId);
  }

  static async validateSession(tokenJti: string): Promise<string | null> {
    const redis = getRedis();
    const key = SESSION_KEY.replace('{token}', tokenJti);
    return redis.get(key);
  }

  static async revokeSession(tokenJti: string): Promise<void> {
    const redis = getRedis();
    await redis.del(SESSION_KEY.replace('{token}', tokenJti));
  }

  static async createEphemeralMatch(matchId: string, payload: Record<string, any>): Promise<void> {
    const redis = getRedis();
    const key = MATCH_EPHEMERAL.replace('{matchId}', matchId);
    await redis.setEx(key, 900, JSON.stringify(payload));
  }

  static async getEphemeralMatch(matchId: string): Promise<Record<string, any> | null> {
    const redis = getRedis();
    const key = MATCH_EPHEMERAL.replace('{matchId}', matchId);
    const data = await redis.get(key);
    return data ? JSON.parse(data) : null;
  }

  static async extendEphemeralMatch(matchId: string, additionalSeconds: number): Promise<void> {
    const redis = getRedis();
    const key = MATCH_EPHEMERAL.replace('{matchId}', matchId);
    await redis.expire(key, additionalSeconds);
  }

  static async addActiveMatch(userId: string, matchId: string): Promise<void> {
    const redis = getRedis();
    const key = ACTIVE_MATCHES.replace('{userId}', userId);
    await redis.sAdd(key, matchId);
    await redis.expire(key, 86400);
  }

  static async removeActiveMatch(userId: string, matchId: string): Promise<void> {
    const redis = getRedis();
    const key = ACTIVE_MATCHES.replace('{userId}', userId);
    await redis.sRem(key, matchId);
  }

  static async getActiveMatches(userId: string): Promise<string[]> {
    const redis = getRedis();
    const key = ACTIVE_MATCHES.replace('{userId}', userId);
    return redis.sMembers(key);
  }

  static async cacheBleProximity(userId: string, detectedDeviceId: string, rssi: number): Promise<void> {
    const redis = getRedis();
    const key = BLE_PROXIMITY.replace('{userId}', userId);
    const timestamp = Date.now();
    await redis.zAdd(key, { score: rssi, value: `${detectedDeviceId}:${timestamp}` });
    await redis.expire(key, 60);
  }

  static async getBleProximity(userId: string): Promise<Array<{ deviceId: string; rssi: number; timestamp: number }>> {
    const redis = getRedis();
    const key = BLE_PROXIMITY.replace('{userId}', userId);
    const items = await redis.zRangeWithScores(key, 0, -1);
    return items.map((item: any) => {
      const [deviceId, timestamp] = item.value.split(':');
      return { deviceId, rssi: item.score, timestamp: parseInt(timestamp, 10) };
    });
  }

  static async checkRateLimit(key: string, maxRequests: number, windowSec: number): Promise<boolean> {
    const redis = getRedis();
    const fullKey = RATE_LIMIT.replace('{key}', key);
    const current = await redis.incr(fullKey);
    if (current === 1) await redis.expire(fullKey, windowSec);
    return current <= maxRequests;
  }

  static async cacheAvailability(userId: string, availability: any[]): Promise<void> {
    const redis = getRedis();
    const key = CALENDAR_CACHE.replace('{userId}', userId);
    await redis.setEx(key, 900, JSON.stringify(availability));
  }

  static async getCachedAvailability(userId: string): Promise<any[] | null> {
    const redis = getRedis();
    const key = CALENDAR_CACHE.replace('{userId}', userId);
    const data = await redis.get(key);
    return data ? JSON.parse(data) : null;
  }

  // Geo methods
  static async updateLocation(userId: string, longitude: number, latitude: number, accuracy?: number): Promise<void> {
    const redis = getRedis();
    const timestamp = Date.now();
    await redis.geoAdd(GEO_KEY, { longitude, latitude, member: userId });
    const locKey = USER_LOC_KEY.replace('{userId}', userId);
    await redis.hSet(locKey, {
      lat: latitude.toString(),
      lon: longitude.toString(),
      accuracy: (accuracy ?? -1).toString(),
      updatedAt: timestamp.toString(),
    });
    await redis.expire(locKey, 300);
  }

  static async findNearbyUsers(userId: string, radiusMeters: number = 500): Promise<Array<{ userId: string; distanceM: number }>> {
    const redis = getRedis();
    const nearby = await redis.geoSearchWith(GEO_KEY, userId, { radius: radiusMeters, unit: 'm' }, 'WITHDIST');
    return nearby
      .filter((n: any) => n.member !== userId)
      .map((n: any) => ({ userId: n.member, distanceM: parseFloat(n.distance) }));
  }

  static async removeLocation(userId: string): Promise<void> {
    const redis = getRedis();
    await redis.zRem(GEO_KEY, userId);
    await redis.del(USER_LOC_KEY.replace('{userId}', userId));
  }
}
