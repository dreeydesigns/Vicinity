import { prisma } from '../../lib/prisma';
import { PushService } from '../notification/push.service';

export class SafetyService {
  /**
   * Block a user
   */
  static async blockUser(blockerId: string, blockedId: string, reason?: string): Promise<void> {
    if (blockerId === blockedId) throw new Error('Cannot block yourself');

    await prisma.blockedUser.create({
      data: {
        blockerId,
        blockedId,
        reason,
      },
    });

    // Expire any active matches
    const activeMatches = await prisma.match.findMany({
      where: {
        OR: [
          { user1Id: blockerId, user2Id: blockedId },
          { user1Id: blockedId, user2Id: blockerId },
        ],
        status: { in: ['PROXIMITY_DETECTED', 'PENDING_SCHEDULE', 'SCHEDULED', 'ACCEPTED'] },
      },
    });

    for (const match of activeMatches) {
      await prisma.match.update({
        where: { id: match.id },
        data: { status: 'CANCELLED', cancellationReason: 'User blocked' },
      });
    }
  }

  /**
   * Report a user
   */
  static async reportUser(
    reporterId: string,
    reportedId: string,
    category: string,
    description?: string,
    matchId?: string
  ): Promise<void> {
    await prisma.report.create({
      data: {
        reporterId,
        reportedId,
        matchId,
        category,
        description,
      },
    });

    // Auto-block if report is severe
    if (['harassment', 'safety_concern'].includes(category)) {
      await this.blockUser(reporterId, reportedId, `Auto-blocked: ${category}`);
    }
  }

  /**
   * Trigger safety check during active date
   */
  static async triggerSafetyCheck(matchId: string): Promise<void> {
    const match = await prisma.match.findUnique({
      where: { id: matchId },
    });

    if (!match) return;

    await PushService.sendNotification(match.user1Id, {
      title: 'Safety Check',
      body: 'Tap to confirm you are safe.',
      data: { matchId, type: 'SAFETY_CHECK' },
    });

    await PushService.sendNotification(match.user2Id, {
      title: 'Safety Check',
      body: 'Tap to confirm you are safe.',
      data: { matchId, type: 'SAFETY_CHECK' },
    });
  }
}
