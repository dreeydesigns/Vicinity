import crypto from 'crypto';
import { sha256, computeSharedSecret } from '../../lib/crypto-utils';

const ALGORITHM = 'aes-256-gcm';
const KEY_LENGTH = 32;
const IV_LENGTH = 16;
const AUTH_TAG_LENGTH = 16;
const SALT_LENGTH = 32;

export interface WalletPayload {
  phoneNumber: string;
  email?: string;
  instagram?: string;
  telegram?: string;
  bioSnippet: string;
  displayName: string;
}

export interface EncryptedWallet {
  encryptedPayload: string;
  iv: string;
  authTag: string;
  salt: string;
}

export class WalletEncryptionService {
  /**
   * Derive AES-256 key from ECDH shared secret + salt
   */
  static deriveKey(sharedSecret: string, salt: Buffer): Buffer {
    return crypto.pbkdf2Sync(sharedSecret, salt, 100000, KEY_LENGTH, 'sha256');
  }

  /**
   * Encrypt wallet payload using AES-256-GCM with ECDH-derived key
   */
  static encrypt(
    payload: WalletPayload,
    sharedSecret: string
  ): EncryptedWallet {
    const salt = crypto.randomBytes(SALT_LENGTH);
    const iv = crypto.randomBytes(IV_LENGTH);
    const key = this.deriveKey(sharedSecret, salt);

    const cipher = crypto.createCipheriv(ALGORITHM, key, iv);
    const plaintext = JSON.stringify(payload);
    const encrypted = Buffer.concat([cipher.update(plaintext, 'utf8'), cipher.final()]);
    const authTag = cipher.getAuthTag();

    return {
      encryptedPayload: encrypted.toString('base64'),
      iv: iv.toString('hex'),
      authTag: authTag.toString('hex'),
      salt: salt.toString('hex'),
    };
  }

  /**
   * Decrypt wallet payload
   */
  static decrypt(
    encryptedWallet: EncryptedWallet,
    sharedSecret: string
  ): WalletPayload {
    const key = this.deriveKey(
      sharedSecret,
      Buffer.from(encryptedWallet.salt, 'hex')
    );

    const decipher = crypto.createDecipheriv(
      ALGORITHM,
      key,
      Buffer.from(encryptedWallet.iv, 'hex')
    );
    decipher.setAuthTag(Buffer.from(encryptedWallet.authTag, 'hex'));

    const decrypted = Buffer.concat([
      decipher.update(Buffer.from(encryptedWallet.encryptedPayload, 'base64')),
      decipher.final(),
    ]);

    return JSON.parse(decrypted.toString('utf8'));
  }

  /**
   * Generate ECDH key pair for wallet exchange
   */
  static generateKeyPair(): { privateKey: string; publicKey: string } {
    const ecdh = crypto.createECDH('secp256k1');
    ecdh.generateKeys();
    return {
      privateKey: ecdh.getPrivateKey('hex'),
      publicKey: ecdh.getPublicKey('hex', 'compressed'),
    };
  }

  /**
   * Compute shared secret
   */
  static computeShared(privateKey: string, publicKey: string): string {
    return computeSharedSecret(privateKey, publicKey);
  }

  /**
   * Hash shared secret for storage verification
   */
  static hashSharedSecret(sharedSecret: string): string {
    return sha256(sharedSecret);
  }
}
