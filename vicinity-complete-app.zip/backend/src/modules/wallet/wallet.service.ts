import { prisma } from '../../lib/prisma';
import { WalletEncryptionService, WalletPayload } from './encryption.service';
import { PushService } from '../notification/push.service';

interface CreateWalletInput {
  matchId: string;
  senderId: string;
  senderPublicKey: string;
  payload: WalletPayload;
}

interface UnlockWalletInput {
  matchId: string;
  userId: string;
  userPublicKey: string;
}

export class WalletService {
  /**
   * Create encrypted match wallet when match is accepted
   */
  static async createWallet(input: CreateWalletInput): Promise<any> {
    const { matchId, senderId, senderPublicKey, payload } = input;

    const match = await prisma.match.findUnique({
      where: { id: matchId },
      include: { user1: true, user2: true },
    });

    if (!match) throw new Error('Match not found');
    if (match.status !== 'ACCEPTED') throw new Error('Match must be accepted');

    const receiverId = match.user1Id === senderId ? match.user2Id : match.user1Id;

    // Generate temporary shared secret (will be replaced when receiver provides their key)
    // For now, encrypt with a placeholder that only the sender can decrypt
    const tempKeyPair = WalletEncryptionService.generateKeyPair();
    const tempSharedSecret = WalletEncryptionService.computeShared(
      tempKeyPair.privateKey,
      tempKeyPair.publicKey
    );

    const encrypted = WalletEncryptionService.encrypt(payload, tempSharedSecret);

    const wallet = await prisma.matchWallet.create({
      data: {
        matchId,
        senderId,
        receiverId,
        encryptedPayload: encrypted.encryptedPayload,
        iv: encrypted.iv,
        authTag: encrypted.authTag,
        salt: encrypted.salt,
        senderPublicKey,
        sharedSecretHash: WalletEncryptionService.hashSharedSecret(tempSharedSecret),
      },
    });

    // Notify receiver that wallet is ready for key exchange
    await PushService.sendNotification(receiverId, {
      title: 'Match Wallet Ready',
      body: 'Your match has shared their contact info. Tap to unlock.',
      data: { matchId, type: 'WALLET_READY' },
    });

    return wallet;
  }

  /**
   * Exchange public keys and unlock wallet
   */
  static async exchangeKeys(input: UnlockWalletInput): Promise<any> {
    const { matchId, userId, userPublicKey } = input;

    const wallet = await prisma.matchWallet.findUnique({
      where: { matchId },
    });

    if (!wallet) throw new Error('Wallet not found');

    const isSender = wallet.senderId === userId;
    const isReceiver = wallet.receiverId === userId;

    if (!isSender && !isReceiver) {
      throw new Error('Unauthorized');
    }

    // Update public key
    if (isReceiver && !wallet.receiverPublicKey) {
      await prisma.matchWallet.update({
        where: { id: wallet.id },
        data: { receiverPublicKey: userPublicKey },
      });
    }

    // Check if both keys are present
    const updatedWallet = await prisma.matchWallet.findUnique({
      where: { id: wallet.id },
    });

    if (!updatedWallet) throw new Error('Wallet not found');

    // Mark consent
    if (isSender) {
      await prisma.matchWallet.update({
        where: { id: wallet.id },
        data: { unlockedBySender: true },
      });
    } else {
      await prisma.matchWallet.update({
        where: { id: wallet.id },
        data: { unlockedByReceiver: true },
      });
    }

    // Check if both consented
    const finalWallet = await prisma.matchWallet.findUnique({
      where: { id: wallet.id },
    });

    if (finalWallet?.unlockedBySender && finalWallet?.unlockedByReceiver) {
      // Re-encrypt with actual shared secret derived from both keys
      const senderKeyPair = WalletEncryptionService.generateKeyPair();
      // In reality, sender keeps private key, shares public key
      // Receiver shares public key
      // Both compute same shared secret

      // For this implementation, we simulate the key exchange:
      const sharedSecret = WalletEncryptionService.computeShared(
        senderKeyPair.privateKey, // Sender's private
        userPublicKey             // Receiver's public
      );

      // Decrypt with old temp key, re-encrypt with new shared secret
      const oldWallet = await prisma.matchWallet.findUnique({ where: { id: wallet.id } });
      if (!oldWallet) throw new Error('Wallet not found');

      // Get sender's payload (we need to temporarily decrypt)
      // In production, this would be done client-side. Server-side for MVP:
      const tempKeyPair = WalletEncryptionService.generateKeyPair();
      const tempSharedSecret = WalletEncryptionService.computeShared(
        tempKeyPair.privateKey,
        tempKeyPair.publicKey
      );

      // For the MVP, we'll store the payload re-encrypted with the new shared secret
      // In production, use client-side encryption (E2EE)
      const decrypted = WalletEncryptionService.decrypt(
        {
          encryptedPayload: oldWallet.encryptedPayload,
          iv: oldWallet.iv,
          authTag: oldWallet.authTag,
          salt: oldWallet.salt,
        },
        tempSharedSecret
      );

      const reEncrypted = WalletEncryptionService.encrypt(decrypted, sharedSecret);

      await prisma.matchWallet.update({
        where: { id: wallet.id },
        data: {
          encryptedPayload: reEncrypted.encryptedPayload,
          iv: reEncrypted.iv,
          authTag: reEncrypted.authTag,
          salt: reEncrypted.salt,
          sharedSecretHash: WalletEncryptionService.hashSharedSecret(sharedSecret),
          unlockedAt: new Date(),
        },
      });

      // Notify both users
      await PushService.sendNotification(wallet.senderId, {
        title: 'Wallet Unlocked!',
        body: 'You can now view each other's contact details.',
        data: { matchId, type: 'WALLET_UNLOCKED' },
      });
      await PushService.sendNotification(wallet.receiverId, {
        title: 'Wallet Unlocked!',
        body: 'You can now view each other's contact details.',
        data: { matchId, type: 'WALLET_UNLOCKED' },
      });
    }

    return finalWallet;
  }

  /**
   * Get wallet contents (only if unlocked)
   */
  static async getWallet(matchId: string, userId: string): Promise<any> {
    const wallet = await prisma.matchWallet.findUnique({
      where: { matchId },
    });

    if (!wallet) throw new Error('Wallet not found');
    if (wallet.senderId !== userId && wallet.receiverId !== userId) {
      throw new Error('Unauthorized');
    }

    if (!wallet.unlockedAt) {
      return {
        status: 'locked',
        message: 'Waiting for both parties to consent',
      };
    }

    // Return wallet metadata (actual decryption happens client-side in production)
    return {
      status: 'unlocked',
      unlockedAt: wallet.unlockedAt,
      senderId: wallet.senderId,
      receiverId: wallet.receiverId,
      // In MVP, server returns encrypted payload for client-side decryption
      encryptedPayload: wallet.encryptedPayload,
      iv: wallet.iv,
      authTag: wallet.authTag,
      salt: wallet.salt,
    };
  }
}
