import { Request, Response, NextFunction } from 'express';
import { WalletService } from './wallet.service';
import { z } from 'zod';

const createSchema = z.object({
  matchId: z.string().cuid(),
  senderPublicKey: z.string().min(1),
  payload: z.object({
    phoneNumber: z.string().min(1),
    email: z.string().email().optional(),
    instagram: z.string().optional(),
    telegram: z.string().optional(),
    bioSnippet: z.string().min(1),
    displayName: z.string().min(1),
  }),
});

const exchangeSchema = z.object({
  matchId: z.string().cuid(),
  userPublicKey: z.string().min(1),
});

export class WalletController {
  static async createWallet(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const senderId = (req as any).user.id;
      const data = createSchema.parse(req.body);
      const wallet = await WalletService.createWallet({
        matchId: data.matchId,
        senderId,
        senderPublicKey: data.senderPublicKey,
        payload: data.payload,
      });
      res.status(201).json(wallet);
    } catch (error) {
      next(error);
    }
  }

  static async exchangeKeys(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const userId = (req as any).user.id;
      const data = exchangeSchema.parse(req.body);
      const result = await WalletService.exchangeKeys({
        matchId: data.matchId,
        userId,
        userPublicKey: data.userPublicKey,
      });
      res.status(200).json(result);
    } catch (error) {
      next(error);
    }
  }

  static async getWallet(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const userId = (req as any).user.id;
      const { matchId } = req.params;
      const wallet = await WalletService.getWallet(matchId, userId);
      res.status(200).json(wallet);
    } catch (error) {
      next(error);
    }
  }
}
