import { Router } from 'express';
import { WalletController } from './wallet.controller';
import { authenticate } from '../../middleware/auth.middleware';

const router = Router();

router.use(authenticate);

router.post('/', WalletController.createWallet);
router.post('/exchange', WalletController.exchangeKeys);
router.get('/:matchId', WalletController.getWallet);

export default router;
