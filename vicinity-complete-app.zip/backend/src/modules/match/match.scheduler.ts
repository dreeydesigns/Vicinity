import { prisma } from '../../lib/prisma';
import { MatchService } from './match.service';
import { PushService } from '../notification/push.service';

/**
 * Background job runner for match expiry
 * Should be triggered by a cron job every minute (e.g., node-cron or AWS EventBridge)
 */
export class MatchScheduler {
  static async processExpiredMatches(): Promise<number> {
    const expiredMatches = await prisma.match.findMany({
      where: {
        status: { in: ['PROXIMITY_DETECTED', 'PENDING_SCHEDULE'] },
        expiresAt: { lte: new Date() },
      },
    });

    for (const match of expiredMatches) {
      await MatchService.expireMatch(match.id);
    }

    return expiredMatches.length;
  }

  static async sendDateReminders(): Promise<number> {
    const upcomingDates = await prisma.match.findMany({
      where: {
        status: 'SCHEDULED',
        scheduledAt: {
          gte: new Date(),
          lte: new Date(Date.now() + 30 * 60 * 1000), // Within 30 minutes
        },
      },
    });

    for (const match of upcomingDates) {
      await PushService.sendNotification(match.user1Id, {
        title: 'Date Reminder',
        body: `Your date at ${match.venueName} is in 30 minutes!`,
        data: { matchId: match.id, type: 'DATE_REMINDER' },
      });
      await PushService.sendNotification(match.user2Id, {
        title: 'Date Reminder',
        body: `Your date at ${match.venueName} is in 30 minutes!`,
        data: { matchId: match.id, type: 'DATE_REMINDER' },
      });
    }

    return upcomingDates.length;
  }

  static async cleanupStaleLocations(): Promise<number> {
    // Remove users who haven't updated location in 10 minutes
    // This is handled by Redis TTL, but we also clean PostgreSQL
    const staleThreshold = new Date(Date.now() - 10 * 60 * 1000);

    const result = await prisma.userLocation.deleteMany({
      where: {
        gpsLastSeenAt: { lt: staleThreshold },
      },
    });

    return result.count;
  }
}
