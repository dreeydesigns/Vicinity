import { prisma } from '../../lib/prisma';
import { RedisSessionService } from '../../services/redis.service';
import { PushService } from '../notification/push.service';
import { MatchStatus } from '@prisma/client';

interface CreateMatchInput {
  user1Id: string;
  user2Id: string;
  detectionMethod: string;
  initialDistanceM: number;
  compatibilityScore: number;
}

export class MatchService {
  static async createMatch(input: CreateMatchInput) {
    const { user1Id, user2Id, detectionMethod, initialDistanceM, compatibilityScore } = input;

    // Ensure consistent ordering (alphabetical by userId)
    const [firstId, secondId] = [user1Id, user2Id].sort();

    const match = await prisma.match.create({
      data: {
        user1Id: firstId,
        user2Id: secondId,
        status: 'PROXIMITY_DETECTED',
        detectionMethod,
        initialDistanceM,
        compatibilityScore,
        expiresAt: new Date(Date.now() + 15 * 60 * 1000), // 15 minutes
      },
    });

    // Store ephemeral match state in Redis
    await RedisSessionService.createEphemeralMatch(match.id, {
      user1Id: firstId,
      user2Id: secondId,
      status: 'PROXIMITY_DETECTED',
      createdAt: Date.now(),
    });

    await RedisSessionService.addActiveMatch(firstId, match.id);
    await RedisSessionService.addActiveMatch(secondId, match.id);

    // Send push notifications to both users
    await PushService.sendMatchNotification(firstId, {
      matchId: match.id,
      compatibilityScore,
      message: 'Someone compatible is nearby!',
    });

    await PushService.sendMatchNotification(secondId, {
      matchId: match.id,
      compatibilityScore,
      message: 'Someone compatible is nearby!',
    });

    return match;
  }

  static async getMatch(userId: string, matchId: string) {
    const match = await prisma.match.findFirst({
      where: {
        id: matchId,
        OR: [{ user1Id: userId }, { user2Id: userId }],
      },
      include: {
        user1: { include: { profile: true } },
        user2: { include: { profile: true } },
      },
    });

    if (!match) throw new Error('Match not found');
    return match;
  }

  static async getActiveMatches(userId: string) {
    const matchIds = await RedisSessionService.getActiveMatches(userId);

    if (matchIds.length === 0) return [];

    const matches = await prisma.match.findMany({
      where: {
        id: { in: matchIds },
        OR: [{ user1Id: userId }, { user2Id: userId }],
        status: { in: ['PROXIMITY_DETECTED', 'PENDING_SCHEDULE', 'SCHEDULED', 'ACCEPTED'] },
      },
      include: {
        user1: { include: { profile: { select: { displayName: true, photos: true, bio: true } } } },
        user2: { include: { profile: { select: { displayName: true, photos: true, bio: true } } } },
      },
      orderBy: { createdAt: 'desc' },
    });

    return matches;
  }

  static async updateMatchStatus(matchId: string, status: MatchStatus, metadata?: any) {
    const updateData: any = { status };

    if (status === 'ACCEPTED') {
      updateData.user1ConsentAt = metadata?.user1Consent ? new Date() : undefined;
      updateData.user2ConsentAt = metadata?.user2Consent ? new Date() : undefined;
    }

    if (status === 'SCHEDULED') {
      updateData.scheduledAt = metadata?.scheduledAt;
      updateData.venueId = metadata?.venueId;
      updateData.venueName = metadata?.venueName;
      updateData.venueAddress = metadata?.venueAddress;
      updateData.venueLatitude = metadata?.venueLatitude;
      updateData.venueLongitude = metadata?.venueLongitude;
      updateData.venueType = metadata?.venueType;
    }

    const match = await prisma.match.update({
      where: { id: matchId },
      data: updateData,
    });

    // Update Redis ephemeral state
    const ephemeral = await RedisSessionService.getEphemeralMatch(matchId);
    if (ephemeral) {
      ephemeral.status = status;
      await RedisSessionService.createEphemeralMatch(matchId, ephemeral);
    }

    return match;
  }

  static async handleConsent(matchId: string, userId: string): Promise<{
    match: any;
    bothConsented: boolean;
  }> {
    const match = await prisma.match.findUnique({ where: { id: matchId } });
    if (!match) throw new Error('Match not found');

    const isUser1 = match.user1Id === userId;
    const updateData: any = {};

    if (isUser1) {
      updateData.user1ConsentAt = new Date();
    } else {
      updateData.user2ConsentAt = new Date();
    }

    const updated = await prisma.match.update({
      where: { id: matchId },
      data: updateData,
      include: {
        user1: { include: { profile: true } },
        user2: { include: { profile: true } },
      },
    });

    const bothConsented = !!updated.user1ConsentAt && !!updated.user2ConsentAt;

    if (bothConsented) {
      await this.updateMatchStatus(matchId, 'ACCEPTED');

      // Extend ephemeral window for date planning
      await RedisSessionService.extendEphemeralMatch(matchId, 3600); // +1 hour

      // Notify both users
      await PushService.sendNotification(match.user1Id, {
        title: 'It's a Match!',
        body: 'You both agreed to meet. Planning your date now...',
        data: { matchId, type: 'MATCH_ACCEPTED' },
      });
      await PushService.sendNotification(match.user2Id, {
        title: 'It's a Match!',
        body: 'You both agreed to meet. Planning your date now...',
        data: { matchId, type: 'MATCH_ACCEPTED' },
      });
    }

    return { match: updated, bothConsented };
  }

  static async expireMatch(matchId: string): Promise<void> {
    const match = await prisma.match.findUnique({ where: { id: matchId } });
    if (!match) return;

    await prisma.match.update({
      where: { id: matchId },
      data: { status: 'EXPIRED' },
    });

    await RedisSessionService.removeActiveMatch(match.user1Id, matchId);
    await RedisSessionService.removeActiveMatch(match.user2Id, matchId);

    // Notify users
    await PushService.sendNotification(match.user1Id, {
      title: 'Match Expired',
      body: 'Your match window has closed.',
      data: { matchId, type: 'MATCH_EXPIRED' },
    });
    await PushService.sendNotification(match.user2Id, {
      title: 'Match Expired',
      body: 'Your match window has closed.',
      data: { matchId, type: 'MATCH_EXPIRED' },
    });
  }
}
