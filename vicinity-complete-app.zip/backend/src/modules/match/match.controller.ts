import { Request, Response, NextFunction } from 'express';
import { MatchService } from './match.service';
import { z } from 'zod';

const consentSchema = z.object({
  matchId: z.string().cuid(),
});

const scheduleSchema = z.object({
  matchId: z.string().cuid(),
  venueId: z.string().min(1),
  venueName: z.string().min(1),
  venueAddress: z.string().min(1),
  venueLatitude: z.number(),
  venueLongitude: z.number(),
  venueType: z.enum(['CAFE', 'BAR', 'RESTAURANT', 'PARK', 'MUSEUM', 'BOOKSTORE', 'COCKTAIL_LOUNGE']),
  scheduledAt: z.string().datetime(),
});

export class MatchController {
  static async getActiveMatches(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const userId = (req as any).user.id;
      const matches = await MatchService.getActiveMatches(userId);
      res.status(200).json({ matches });
    } catch (error) {
      next(error);
    }
  }

  static async getMatch(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const userId = (req as any).user.id;
      const { matchId } = req.params;
      const match = await MatchService.getMatch(userId, matchId);
      res.status(200).json({ match });
    } catch (error) {
      next(error);
    }
  }

  static async giveConsent(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const userId = (req as any).user.id;
      const { matchId } = consentSchema.parse(req.body);
      const result = await MatchService.handleConsent(matchId, userId);
      res.status(200).json(result);
    } catch (error) {
      next(error);
    }
  }

  static async scheduleDate(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const data = scheduleSchema.parse(req.body);
      const match = await MatchService.updateMatchStatus(data.matchId, 'SCHEDULED', {
        scheduledAt: new Date(data.scheduledAt),
        venueId: data.venueId,
        venueName: data.venueName,
        venueAddress: data.venueAddress,
        venueLatitude: data.venueLatitude,
        venueLongitude: data.venueLongitude,
        venueType: data.venueType,
      });
      res.status(200).json({ match });
    } catch (error) {
      next(error);
    }
  }
}
