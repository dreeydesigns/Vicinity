import { Router } from 'express';
import { MatchController } from './match.controller';
import { authenticate } from '../../middleware/auth.middleware';

const router = Router();

router.use(authenticate);

router.get('/active', MatchController.getActiveMatches);
router.get('/:matchId', MatchController.getMatch);
router.post('/consent', MatchController.giveConsent);
router.post('/schedule', MatchController.scheduleDate);

export default router;
