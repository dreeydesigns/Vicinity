import { sha256, secureCompare } from '../../lib/crypto-utils';

/**
 * Zero-Knowledge Proximity Proof Service
 * 
 * Instead of sending exact GPS coordinates to the server,
 * users compute proximity proofs locally and only share
 * hashed location grids with the server.
 */

export class ZKPService {
  static readonly GEOHASH_PRECISION = 6; // ~150m x 150m cells

  /**
   * Compute a geohash from latitude/longitude
   * Using a simplified base32 geohash implementation
   */
  static computeGeohash(latitude: number, longitude: number, precision: number = this.GEOHASH_PRECISION): string {
    const base32 = '0123456789bcdefghjkmnpqrstuvwxyz';
    let idx = 0;
    let bit = 0;
    let evenBit = true;
    let geohash = '';

    let latRange = { min: -90, max: 90 };
    let lonRange = { min: -180, max: 180 };

    while (geohash.length < precision) {
      if (evenBit) {
        const mid = (lonRange.min + lonRange.max) / 2;
        if (longitude >= mid) {
          idx = idx * 2 + 1;
          lonRange.min = mid;
        } else {
          idx = idx * 2;
          lonRange.max = mid;
        }
      } else {
        const mid = (latRange.min + latRange.max) / 2;
        if (latitude >= mid) {
          idx = idx * 2 + 1;
          latRange.min = mid;
        } else {
          idx = idx * 2;
          latRange.max = mid;
        }
      }

      evenBit = !evenBit;
      bit++;

      if (bit === 5) {
        geohash += base32[idx];
        bit = 0;
        idx = 0;
      }
    }

    return geohash;
  }

  /**
   * Generate a zero-knowledge proximity proof
   * User sends: H(geohash + secret + timestamp)
   * Server verifies by checking if any other user is in the same geohash
   */
  static generateProximityProof(
    latitude: number,
    longitude: number,
    secret: string,
    timestamp: number
  ): { geohash: string; proof: string; timestamp: number } {
    const geohash = this.computeGeohash(latitude, longitude);
    const proof = sha256(`${geohash}:${secret}:${timestamp}`);
    return { geohash, proof, timestamp };
  }

  /**
   * Verify that two users are in the same geohash cell
   * without revealing exact coordinates
   */
  static verifySameCell(geohash1: string, geohash2: string): boolean {
    return geohash1 === geohash2;
  }

  /**
   * Get neighboring geohashes for expanded search
   */
  static getNeighbors(geohash: string): string[] {
    // Simplified: return the geohash and its 8 neighbors
    // In production, use a proper geohash library
    return [geohash]; // Placeholder - actual implementation needs geohash library
  }

  /**
   * Create a blinded location token for server-side matching
   * The server can check if two tokens match without knowing the location
   */
  static createBlindedToken(
    latitude: number,
    longitude: number,
    userSecret: string,
    salt: string
  ): string {
    const geohash = this.computeGeohash(latitude, longitude);
    return sha256(`${geohash}:${userSecret}:${salt}`);
  }

  /**
   * Verify if two blinded tokens represent the same geohash
   * Requires both parties to share their salts after initial match
   */
  static verifyBlindedMatch(
    token1: string,
    token2: string,
    geohash: string,
    secret1: string,
    salt1: string,
    secret2: string,
    salt2: string
  ): boolean {
    const expected1 = sha256(`${geohash}:${secret1}:${salt1}`);
    const expected2 = sha256(`${geohash}:${secret2}:${salt2}`);
    return secureCompare(token1, expected1) && secureCompare(token2, expected2);
  }
}
