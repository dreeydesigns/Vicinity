import { prisma } from '../../lib/prisma';
import { RedisSessionService } from '../../services/redis.service';
import { MatchService } from '../match/match.service';

interface ProximityMatchInput {
  userId: string;
  longitude: number;
  latitude: number;
  accuracy?: number;
  bleDeviceIds?: string[]; // Nearby BLE device IDs
  bleRssi?: Record<string, number>; // deviceId -> RSSI
}

export class ProximityService {
  static readonly MATCH_RADIUS_METERS = 500;
  static readonly MIN_COMPATIBILITY_SCORE = 70;

  /**
   * Main entry: user reports location + BLE scan results
   */
  static async reportLocation(input: ProximityMatchInput): Promise<{
    matchesFound: number;
    matchIds: string[];
  }> {
    const { userId, longitude, latitude, accuracy, bleDeviceIds, bleRssi } = input;

    // Update Redis geospatial index
    await RedisSessionService.updateLocation(userId, longitude, latitude, accuracy);

    // Cache BLE proximity data
    if (bleDeviceIds && bleRssi) {
      for (const deviceId of bleDeviceIds) {
        const rssi = bleRssi[deviceId] || -100;
        await RedisSessionService.cacheBleProximity(userId, deviceId, rssi);
      }
    }

    // Find nearby users via GPS
    const gpsNearby = await RedisSessionService.findNearbyUsers(
      userId,
      this.MATCH_RADIUS_METERS
    );

    // Find BLE-enhanced matches
    const bleMatches = await this.findBleMatches(userId, bleDeviceIds || []);

    // Merge and deduplicate
    const candidateMap = new Map<string, { distanceM: number; source: 'gps' | 'ble' | 'hybrid' }>();

    for (const n of gpsNearby) {
      candidateMap.set(n.userId, { distanceM: n.distanceM, source: 'gps' });
    }

    for (const b of bleMatches) {
      const existing = candidateMap.get(b.userId);
      if (existing) {
        existing.source = 'hybrid';
        existing.distanceM = Math.min(existing.distanceM, b.distanceM);
      } else {
        candidateMap.set(b.userId, { distanceM: b.distanceM, source: 'ble' });
      }
    }

    // Evaluate each candidate
    const matchIds: string[] = [];
    for (const [candidateId, proximityData] of candidateMap) {
      const match = await this.evaluateMatch(userId, candidateId, proximityData);
      if (match) {
        matchIds.push(match.id);
      }
    }

    return { matchesFound: matchIds.length, matchIds };
  }

  /**
   * Find users whose BLE device IDs were detected
   */
  private static async findBleMatches(
    userId: string,
    detectedDeviceIds: string[]
  ): Promise<Array<{ userId: string; distanceM: number }>> {
    if (detectedDeviceIds.length === 0) return [];

    // Look up profiles by BLE device ID
    const profiles = await prisma.profile.findMany({
      where: {
        bleDeviceId: { in: detectedDeviceIds },
        userId: { not: userId },
      },
      select: { userId: true, bleDeviceId: true },
    });

    return profiles.map((p) => ({
      userId: p.userId,
      distanceM: 50, // BLE implies very close (<100m typically)
    }));
  }

  /**
   * Evaluate if two users should be matched
   */
  private static async evaluateMatch(
    userId: string,
    candidateId: string,
    proximityData: { distanceM: number; source: string }
  ): Promise<{ id: string } | null> {
    // Check active hours
    const [user1, user2] = await Promise.all([
      prisma.profile.findUnique({
        where: { userId },
        select: {
          activeHoursStart: true,
          activeHoursEnd: true,
          maxDistanceMeters: true,
          gender: true,
          genderPreference: true,
          ageMin: true,
          ageMax: true,
          lookingFor: true,
          interests: true,
        },
      }),
      prisma.profile.findUnique({
        where: { userId: candidateId },
        select: {
          activeHoursStart: true,
          activeHoursEnd: true,
          maxDistanceMeters: true,
          gender: true,
          genderPreference: true,
          dateOfBirth: true,
          lookingFor: true,
          interests: true,
        },
      }),
    ]);

    if (!user1 || !user2) return null;

    // Check active hours
    const hour = new Date().getHours();
    if (hour < user1.activeHoursStart || hour >= user1.activeHoursEnd) return null;
    if (hour < user2.activeHoursStart || hour >= user2.activeHoursEnd) return null;

    // Check max distance
    if (proximityData.distanceM > Math.min(user1.maxDistanceMeters, user2.maxDistanceMeters || 500)) {
      return null;
    }

    // Check gender preferences
    if (user2.gender && !user1.genderPreference.includes(user2.gender)) return null;
    if (user1.gender && user2.genderPreference && !user2.genderPreference.includes(user1.gender)) return null;

    // Check age range
    if (user2.dateOfBirth) {
      const age = this.calculateAge(user2.dateOfBirth);
      if (age < user1.ageMin || age > user1.ageMax) return null;
    }

    // Check looking-for compatibility
    const lookingForOverlap = user1.lookingFor.filter((x) => user2.lookingFor?.includes(x));
    if (lookingForOverlap.length === 0 && user1.lookingFor.length > 0 && user2.lookingFor.length > 0) {
      return null;
    }

    // Calculate compatibility score
    const score = this.calculateCompatibilityScore(user1.interests, user2.interests);
    if (score < this.MIN_COMPATIBILITY_SCORE) return null;

    // Check for existing active match
    const existingMatch = await prisma.match.findFirst({
      where: {
        OR: [
          { user1Id: userId, user2Id: candidateId },
          { user1Id: candidateId, user2Id: userId },
        ],
        status: { in: ['PROXIMITY_DETECTED', 'PENDING_SCHEDULE', 'SCHEDULED', 'ACCEPTED'] },
      },
    });

    if (existingMatch) return null;

    // Check blocks
    const blocked = await prisma.blockedUser.findFirst({
      where: {
        OR: [
          { blockerId: userId, blockedId: candidateId },
          { blockerId: candidateId, blockedId: userId },
        ],
      },
    });

    if (blocked) return null;

    // Create match
    const match = await MatchService.createMatch({
      user1Id: userId,
      user2Id: candidateId,
      detectionMethod: proximityData.source,
      initialDistanceM: proximityData.distanceM,
      compatibilityScore: score,
    });

    return match;
  }

  private static calculateAge(birthDate: Date): number {
    const today = new Date();
    let age = today.getFullYear() - birthDate.getFullYear();
    const monthDiff = today.getMonth() - birthDate.getMonth();
    if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < birthDate.getDate())) {
      age--;
    }
    return age;
  }

  private static calculateCompatibilityScore(interests1: string[], interests2: string[]): number {
    if (!interests1.length || !interests2.length) return 50;
    const set1 = new Set(interests1.map((i) => i.toLowerCase()));
    const set2 = new Set(interests2.map((i) => i.toLowerCase()));
    const intersection = [...set1].filter((x) => set2.has(x));
    const union = new Set([...set1, ...set2]);
    const jaccard = intersection.length / union.size;
    return Math.round(50 + jaccard * 50);
  }
}
