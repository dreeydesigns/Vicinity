import { Request, Response, NextFunction } from 'express';
import { ProximityService } from './proximity.service';
import { z } from 'zod';

const locationSchema = z.object({
  longitude: z.number().min(-180).max(180),
  latitude: z.number().min(-90).max(90),
  accuracy: z.number().min(0).max(100).optional(),
  bleDeviceIds: z.array(z.string().uuid()).optional(),
  bleRssi: z.record(z.string().uuid(), z.number()).optional(),
});

export class ProximityController {
  static async reportLocation(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const userId = (req as any).user.id;
      const data = locationSchema.parse(req.body);

      const result = await ProximityService.reportLocation({
        userId,
        ...data,
      });

      res.status(200).json(result);
    } catch (error) {
      next(error);
    }
  }
}
