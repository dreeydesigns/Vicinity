import { Router } from 'express';
import { ProximityController } from './proximity.controller';
import { authenticate } from '../../middleware/auth.middleware';

const router = Router();

router.use(authenticate);

router.post('/report', ProximityController.reportLocation);

export default router;
