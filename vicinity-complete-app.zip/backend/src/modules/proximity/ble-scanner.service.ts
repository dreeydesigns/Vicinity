/**
 * BLE Scanner Service - Server-side BLE advertisement processing
 * 
 * This service handles the server-side logic for BLE proximity detection.
 * The actual BLE scanning happens on the mobile device (react-native-ble-plx).
 * This service processes the scan results sent from the device.
 */

import { prisma } from '../../lib/prisma';
import { RedisSessionService } from '../../services/redis.service';

interface BleAdvertisement {
  deviceId: string; // BLE UUID
  rssi: number;
  txPower?: number;
  manufacturerData?: string;
  serviceUuids?: string[];
  timestamp: number;
}

export class BleScannerService {
  static readonly VICINITY_SERVICE_UUID = '0000180a-0000-1000-8000-00805f9b34fb';
  static readonly RSSI_CLOSE_THRESHOLD = -65; // dBm (approx 5-10 meters)
  static readonly RSSI_NEAR_THRESHOLD = -80;   // dBm (approx 20-30 meters)

  /**
   * Process BLE advertisements from a user's device
   */
  static async processScanResults(
    userId: string,
    advertisements: BleAdvertisement[]
  ): Promise<Array<{ detectedUserId: string; distanceEstimateM: number; confidence: number }>> {
    const results: Array<{ detectedUserId: string; distanceEstimateM: number; confidence: number }> = [];

    for (const adv of advertisements) {
      // Check if this is a Vicinity user by looking up the BLE device ID
      const profile = await prisma.profile.findUnique({
        where: { bleDeviceId: adv.deviceId },
        select: { userId: true },
      });

      if (!profile || profile.userId === userId) continue;

      // Calculate distance estimate from RSSI
      const distanceEstimate = this.estimateDistance(adv.rssi, adv.txPower);
      const confidence = this.calculateConfidence(adv.rssi, distanceEstimate);

      // Cache the proximity detection
      await RedisSessionService.cacheBleProximity(userId, adv.deviceId, adv.rssi);

      results.push({
        detectedUserId: profile.userId,
        distanceEstimateM: distanceEstimate,
        confidence,
      });
    }

    return results;
  }

  /**
   * Estimate distance from RSSI using log-distance path loss model
   * d = 10^((txPower - rssi) / (10 * n))
   * where n = path loss exponent (2 for free space, 2.5-4 for indoor)
   */
  private static estimateDistance(rssi: number, txPower?: number): number {
    const tx = txPower || -59; // Default TX power for BLE
    const pathLossExponent = 2.5; // Indoor environment
    const distance = Math.pow(10, (tx - rssi) / (10 * pathLossExponent));
    return Math.min(Math.max(distance, 1), 100); // Clamp between 1m and 100m
  }

  /**
   * Calculate confidence score (0-1) based on signal quality
   */
  private static calculateConfidence(rssi: number, distance: number): number {
    if (rssi >= this.RSSI_CLOSE_THRESHOLD) return 0.95;
    if (rssi >= this.RSSI_NEAR_THRESHOLD) return 0.75;
    if (distance <= 20) return 0.6;
    if (distance <= 50) return 0.4;
    return 0.2;
  }

  /**
   * Generate a rotating BLE advertisement UUID for a user
   * This prevents tracking by rotating the UUID every 15 minutes
   */
  static async rotateBleDeviceId(userId: string): Promise<string> {
    const newUuid = crypto.randomUUID();
    await prisma.profile.update({
      where: { userId },
      data: { bleDeviceId: newUuid },
    });
    return newUuid;
  }
}
