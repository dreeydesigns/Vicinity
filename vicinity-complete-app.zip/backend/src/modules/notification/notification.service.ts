import { PushService } from './push.service';

export class NotificationService {
  /**
   * Send safety check notification
   */
  static async sendSafetyCheck(userId: string, matchId: string): Promise<void> {
    await PushService.sendNotification(userId, {
      title: 'Safety Check',
      body: 'Are you safe? Tap to confirm or alert emergency contacts.',
      data: { matchId, type: 'SAFETY_CHECK' },
    });
  }

  /**
   * Send date reminder
   */
  static async sendDateReminder(userId: string, venueName: string, matchId: string): Promise<void> {
    await PushService.sendNotification(userId, {
      title: 'Date Starting Soon',
      body: `Head to ${venueName} for your date!`,
      data: { matchId, type: 'DATE_REMINDER', venueName },
    });
  }
}
