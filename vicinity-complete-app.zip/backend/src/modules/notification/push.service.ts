import { prisma } from '../../lib/prisma';
import { getIO, emitToUser } from '../../websocket/server';

interface PushNotification {
  title: string;
  body: string;
  data?: Record<string, any>;
}

export class PushService {
  /**
   * Send push notification to a user via FCM/APNs
   * Falls back to WebSocket if push token unavailable
   */
  static async sendNotification(userId: string, notification: PushNotification): Promise<void> {
    // Try WebSocket first (real-time)
    try {
      const io = getIO();
      emitToUser(userId, 'notification', notification);
    } catch {
      // WebSocket not available, continue to push
    }

    // Get user's push tokens
    const tokens = await prisma.notificationToken.findMany({
      where: { userId, isActive: true },
    });

    if (tokens.length === 0) return;

    // Send via FCM for Android
    const fcmTokens = tokens.filter((t) => t.platform === 'fcm_android' || t.platform === 'fcm_ios');
    for (const token of fcmTokens) {
      await this.sendFCM(token.token, notification);
    }

    // Send via APNs for iOS
    const apnsTokens = tokens.filter((t) => t.platform === 'apns' || t.platform === 'apns_sandbox');
    for (const token of apnsTokens) {
      await this.sendAPNs(token.token, notification);
    }

    // Send to smartwatch if available
    const watchTokens = tokens.filter((t) => t.watchToken);
    for (const token of watchTokens) {
      await this.sendWatchNotification(token, notification);
    }
  }

  /**
   * Send match-specific notification with haptic payload
   */
  static async sendMatchNotification(userId: string, data: {
    matchId: string;
    compatibilityScore: number;
    message: string;
  }): Promise<void> {
    const notification: PushNotification = {
      title: 'Vicinity Match!',
      body: data.message,
      data: {
        matchId: data.matchId,
        compatibilityScore: data.compatibilityScore,
        type: 'MATCH_NEARBY',
        hapticType: 'MATCH_BUZZ', // Custom haptic pattern
      },
    };

    await this.sendNotification(userId, notification);
  }

  /**
   * Send FCM push notification
   */
  private static async sendFCM(token: string, notification: PushNotification): Promise<void> {
    try {
      const response = await fetch('https://fcm.googleapis.com/fcm/send', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `key=${process.env.FCM_SERVER_KEY}`,
        },
        body: JSON.stringify({
          to: token,
          notification: {
            title: notification.title,
            body: notification.body,
            sound: 'default',
            badge: '1',
          },
          data: notification.data,
          priority: 'high',
        }),
      });

      if (!response.ok) {
        const error = await response.text();
        console.error('FCM send failed:', error);
      }
    } catch (error) {
      console.error('FCM error:', error);
    }
  }

  /**
   * Send APNs push notification
   */
  private static async sendAPNs(token: string, notification: PushNotification): Promise<void> {
    // APNs implementation requires apn library or HTTP/2 connection
    // This is a simplified placeholder
    console.log(`[APNs] Would send to ${token}: ${notification.title}`);
  }

  /**
   * Send watch-specific notification with haptic payload
   */
  private static async sendWatchNotification(
    token: any,
    notification: PushNotification
  ): Promise<void> {
    const hapticPayload = {
      ...notification,
      watchHaptic: {
        type: notification.data?.hapticType || 'DEFAULT',
        intensity: 1.0,
        duration: 500, // ms
      },
    };

    if (token.watchType === 'watchos') {
      // WatchOS push via APNs with WatchKit payload
      console.log(`[WatchOS] Haptic notification: ${notification.title}`);
    } else if (token.watchType === 'wearos') {
      // WearOS via FCM with WearableExtender
      console.log(`[WearOS] Haptic notification: ${notification.title}`);
    }
  }

  /**
   * Register push token for a user
   */
  static async registerToken(
    userId: string,
    token: string,
    platform: string,
    deviceModel?: string,
    osVersion?: string,
    watchToken?: string,
    watchType?: string
  ): Promise<void> {
    await prisma.notificationToken.upsert({
      where: {
        userId_token: { userId, token },
      },
      update: {
        isActive: true,
        lastUsedAt: new Date(),
        deviceModel,
        osVersion,
        watchToken,
        watchType,
      },
      create: {
        userId,
        token,
        platform,
        deviceModel,
        osVersion,
        watchToken,
        watchType,
      },
    });
  }

  /**
   * Deactivate push token (logout, uninstall)
   */
  static async deactivateToken(userId: string, token: string): Promise<void> {
    await prisma.notificationToken.updateMany({
      where: { userId, token },
      data: { isActive: false },
    });
  }
}
