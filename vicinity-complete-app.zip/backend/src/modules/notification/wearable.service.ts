/**
 * Smartwatch Haptic Service
 * Handles WatchOS and WearOS specific haptic patterns
 */

export class WearableService {
  static readonly HAPTIC_PATTERNS = {
    MATCH_BUZZ: {
      watchos: 'notification', // WKHapticType.notification
      wearos: 'click',         // VibrationEffect.EFFECT_CLICK
      pattern: [0, 200, 100, 200, 100, 400], // ms delays
    },
    DATE_REMINDER: {
      watchos: 'directionUp',
      wearos: 'tick',
      pattern: [0, 100, 50, 100],
    },
    WALLET_UNLOCK: {
      watchos: 'success',
      wearos: 'heavyclick',
      pattern: [0, 300],
    },
    SAFETY_ALERT: {
      watchos: 'alarm',
      wearos: 'double_click',
      pattern: [0, 500, 200, 500, 200, 500],
    },
  };

  /**
   * Get haptic configuration for a notification type
   */
  static getHapticConfig(type: string): {
    watchos: string;
    wearos: string;
    pattern: number[];
  } {
    return this.HAPTIC_PATTERNS[type as keyof typeof this.HAPTIC_PATTERNS] || this.HAPTIC_PATTERNS.MATCH_BUZZ;
  }

  /**
   * Build WatchOS notification payload
   */
  static buildWatchOSPayload(notification: any): any {
    const haptic = this.getHapticConfig(notification.data?.hapticType || 'MATCH_BUZZ');
    return {
      aps: {
        alert: {
          title: notification.title,
          body: notification.body,
        },
        sound: 'default',
        category: 'VICINITY_MATCH',
        'watch-companion': {
          hapticType: haptic.watchos,
        },
      },
      ...notification.data,
    };
  }

  /**
   * Build WearOS notification payload
   */
  static buildWearOSPayload(notification: any): any {
    const haptic = this.getHapticConfig(notification.data?.hapticType || 'MATCH_BUZZ');
    return {
      notification: {
        title: notification.title,
        body: notification.body,
      },
        data: {
        ...notification.data,
        wearable: {
          vibrationPattern: haptic.pattern,
          vibrationType: haptic.wearos,
        },
      },
    };
  }
}
