import { prisma } from '../../lib/prisma';
import { Gender } from '@prisma/client';

interface UpdateProfileInput {
  displayName?: string;
  bio?: string;
  dateOfBirth?: Date;
  gender?: Gender;
  genderPreference?: Gender[];
  photos?: string[];
  maxDistanceMeters?: number;
  ageMin?: number;
  ageMax?: number;
  lookingFor?: string[];
  interests?: string[];
  activeHoursStart?: number;
  activeHoursEnd?: number;
  bleDeviceId?: string;
  devicePlatform?: string;
}

export class UserService {
  static async getProfile(userId: string) {
    const user = await prisma.user.findUnique({
      where: { id: userId },
      include: { profile: true, calendarSync: true },
    });
    if (!user) throw new Error('User not found');
    return user;
  }

  static async updateProfile(userId: string, data: UpdateProfileInput) {
    const user = await prisma.user.findUnique({
      where: { id: userId },
      include: { profile: true },
    });

    if (!user) throw new Error('User not found');

    // Upsert profile
    const profile = await prisma.profile.upsert({
      where: { userId },
      create: {
        userId,
        ...data,
      } as any,
      update: data as any,
    });

    // Update onboarding step if needed
    if (user.status === 'PENDING_ONBOARDING' && profile.displayName && profile.photos && (profile.photos as any).length > 0) {
      await prisma.user.update({
        where: { id: userId },
        data: { status: 'ACTIVE', onboardingStep: 4 },
      });
    }

    return profile;
  }

  static async updateOnboardingStep(userId: string, step: number) {
    return prisma.user.update({
      where: { id: userId },
      data: { onboardingStep: step },
    });
  }

  static async deleteAccount(userId: string) {
    // Soft delete
    await prisma.user.update({
      where: { id: userId },
      data: { status: 'DELETED', phoneNumber: `deleted_${userId}` },
    });
  }
}
