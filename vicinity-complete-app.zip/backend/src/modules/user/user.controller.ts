import { Request, Response, NextFunction } from 'express';
import { UserService } from './user.service';
import { z } from 'zod';

const profileSchema = z.object({
  displayName: z.string().min(1).max(50).optional(),
  bio: z.string().max(500).optional(),
  dateOfBirth: z.string().datetime().optional(),
  gender: z.enum(['MALE', 'FEMALE', 'NON_BINARY', 'PREFER_NOT_TO_SAY']).optional(),
  genderPreference: z.array(z.enum(['MALE', 'FEMALE', 'NON_BINARY', 'PREFER_NOT_TO_SAY'])).optional(),
  photos: z.array(z.string().url()).optional(),
  maxDistanceMeters: z.number().min(100).max(2000).optional(),
  ageMin: z.number().min(18).max(100).optional(),
  ageMax: z.number().min(18).max(100).optional(),
  lookingFor: z.array(z.string()).optional(),
  interests: z.array(z.string()).optional(),
  activeHoursStart: z.number().min(0).max(23).optional(),
  activeHoursEnd: z.number().min(0).max(23).optional(),
  bleDeviceId: z.string().uuid().optional(),
  devicePlatform: z.enum(['ios', 'android']).optional(),
});

export class UserController {
  static async getProfile(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const userId = (req as any).user.id;
      const profile = await UserService.getProfile(userId);
      res.status(200).json(profile);
    } catch (error) {
      next(error);
    }
  }

  static async updateProfile(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const userId = (req as any).user.id;
      const data = profileSchema.parse(req.body);

      // Convert dateOfBirth string to Date if provided
      const parsedData: any = { ...data };
      if (data.dateOfBirth) {
        parsedData.dateOfBirth = new Date(data.dateOfBirth);
      }

      const profile = await UserService.updateProfile(userId, parsedData);
      res.status(200).json(profile);
    } catch (error) {
      next(error);
    }
  }

  static async deleteAccount(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const userId = (req as any).user.id;
      await UserService.deleteAccount(userId);
      res.status(200).json({ message: 'Account deleted successfully' });
    } catch (error) {
      next(error);
    }
  }
}
