import { Request, Response, NextFunction } from 'express';
import { AuthService } from './auth.service';
import { GoogleOAuthService } from './google-oauth.service';
import { z } from 'zod';

const phoneSchema = z.object({
  phoneNumber: z.string().min(10).max(15),
});

const otpSchema = z.object({
  phoneNumber: z.string().min(10).max(15),
  otp: z.string().length(6).regex(/^\d+$/),
});

const refreshSchema = z.object({
  refreshToken: z.string().min(1),
});

export class AuthController {
  static async requestOtp(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const { phoneNumber } = phoneSchema.parse(req.body);
      const result = await AuthService.requestOtp(phoneNumber);
      res.status(200).json(result);
    } catch (error) {
      next(error);
    }
  }

  static async verifyOtp(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const { phoneNumber, otp } = otpSchema.parse(req.body);
      const result = await AuthService.verifyOtp(phoneNumber, otp);
      res.status(200).json(result);
    } catch (error) {
      next(error);
    }
  }

  static async refreshToken(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const { refreshToken } = refreshSchema.parse(req.body);
      const result = await AuthService.refreshToken(refreshToken);
      res.status(200).json(result);
    } catch (error) {
      next(error);
    }
  }

  static async logout(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const authHeader = req.headers.authorization;
      const token = authHeader?.split(' ')[1];
      if (token) {
        await AuthService.logout(token);
      }
      res.status(200).json({ message: 'Logged out successfully' });
    } catch (error) {
      next(error);
    }
  }

  static async getGoogleAuthUrl(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const userId = (req as any).user?.id;
      if (!userId) {
        res.status(401).json({ error: 'Authentication required' });
        return;
      }
      const url = GoogleOAuthService.getAuthUrl(userId);
      res.status(200).json({ authUrl: url });
    } catch (error) {
      next(error);
    }
  }

  static async googleCallback(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const { code, state } = req.query as { code: string; state: string };
      const result = await GoogleOAuthService.handleCallback(code, state);
      res.status(200).json(result);
    } catch (error) {
      next(error);
    }
  }
}
