import { GoogleApiService } from '../../lib/google-apis';
import { prisma } from '../../lib/prisma';
import { env } from '../../config/env';
import jwt from 'jsonwebtoken';

export class GoogleOAuthService {
  /**
   * Get Google OAuth authorization URL
   */
  static getAuthUrl(userId: string): string {
    const state = Buffer.from(JSON.stringify({ userId, nonce: Date.now() })).toString('base64');
    return GoogleApiService.getAuthUrl(state);
  }

  /**
   * Handle OAuth callback, link Google account to user
   */
  static async handleCallback(code: string, state: string): Promise<{
    user: any;
    accessToken: string;
    refreshToken: string;
  }> {
    const { tokens, profile } = await GoogleApiService.exchangeCode(code);

    const stateData = JSON.parse(Buffer.from(state, 'base64').toString());
    const userId = stateData.userId;

    // Encrypt tokens before storage
    const encryptedAccess = this.encryptToken(tokens.access_token!);
    const encryptedRefresh = this.encryptToken(tokens.refresh_token!);

    const user = await prisma.user.update({
      where: { id: userId },
      data: {
        googleId: profile.id,
        googleEmail: profile.email,
        googleAccessToken: encryptedAccess,
        googleRefreshToken: encryptedRefresh,
        googleTokenExpiry: tokens.expiry_date ? new Date(tokens.expiry_date) : new Date(Date.now() + 3600 * 1000),
        status: 'ACTIVE',
      },
      include: { profile: true },
    });

    // Generate JWT for mobile session
    const accessToken = jwt.sign(
      { sub: user.id, phone: user.phoneNumber },
      env.JWT_SECRET,
      { expiresIn: '24h', jwtid: this.generateJti() }
    );

    const refreshToken = jwt.sign(
      { sub: user.id, type: 'refresh' },
      env.JWT_REFRESH_SECRET,
      { expiresIn: '30d', jwtid: this.generateJti() }
    );

    return { user, accessToken, refreshToken };
  }

  /**
   * Refresh Google access token for a user
   */
  static async refreshGoogleToken(userId: string): Promise<string> {
    const user = await prisma.user.findUnique({
      where: { id: userId },
      select: { googleRefreshToken: true },
    });

    if (!user?.googleRefreshToken) {
      throw new Error('No refresh token available');
    }

    const decryptedRefresh = this.decryptToken(user.googleRefreshToken);
    const newAccessToken = await GoogleApiService.refreshAccessToken(decryptedRefresh);

    await prisma.user.update({
      where: { id: userId },
      data: {
        googleAccessToken: this.encryptToken(newAccessToken),
        googleTokenExpiry: new Date(Date.now() + 3600 * 1000),
      },
    });

    return newAccessToken;
  }

  private static encryptToken(token: string): string {
    // Simple XOR with master key for demonstration
    // In production, use AWS KMS or HashiCorp Vault
    const key = Buffer.from(env.WALLET_MASTER_KEY, 'base64');
    const buf = Buffer.from(token);
    const encrypted = Buffer.alloc(buf.length);
    for (let i = 0; i < buf.length; i++) {
      encrypted[i] = buf[i] ^ key[i % key.length];
    }
    return encrypted.toString('base64');
  }

  private static decryptToken(encrypted: string): string {
    const key = Buffer.from(env.WALLET_MASTER_KEY, 'base64');
    const buf = Buffer.from(encrypted, 'base64');
    const decrypted = Buffer.alloc(buf.length);
    for (let i = 0; i < buf.length; i++) {
      decrypted[i] = buf[i] ^ key[i % key.length];
    }
    return decrypted.toString('utf8');
  }

  private static generateJti(): string {
    return `${Date.now()}-${Math.random().toString(36).substring(2, 15)}`;
  }
}
