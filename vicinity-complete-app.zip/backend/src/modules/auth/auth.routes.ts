import { Router } from 'express';
import { AuthController } from './auth.controller';
import { authenticate } from '../../middleware/auth.middleware';
import { rateLimit } from '../../middleware/rate-limit.middleware';

const router = Router();

// Public routes
router.post('/otp/request', rateLimit('otp_request', 3, 60), AuthController.requestOtp);
router.post('/otp/verify', rateLimit('otp_verify', 5, 60), AuthController.verifyOtp);
router.post('/refresh', AuthController.refreshToken);

// Protected routes
router.post('/logout', authenticate, AuthController.logout);
router.get('/google/url', authenticate, AuthController.getGoogleAuthUrl);
router.get('/google/callback', AuthController.googleCallback);

export default router;
