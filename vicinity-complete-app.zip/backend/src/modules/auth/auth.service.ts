import { prisma } from '../../lib/prisma';
import { OtpService } from './otp.service';
import { RedisSessionService } from '../../services/redis.service';
import { env } from '../../config/env';
import jwt from 'jsonwebtoken';

export class AuthService {
  /**
   * Step 1: Request OTP for phone number
   */
  static async requestOtp(phoneNumber: string): Promise<{ message: string; devOtp?: string }> {
    // Normalize phone to E.164
    const normalized = this.normalizePhone(phoneNumber);
    return OtpService.requestOtp(normalized);
  }

  /**
   * Step 2: Verify OTP and create/login user
   */
  static async verifyOtp(phoneNumber: string, otp: string): Promise<{
    user: any;
    accessToken: string;
    refreshToken: string;
    isNewUser: boolean;
  }> {
    const normalized = this.normalizePhone(phoneNumber);
    await OtpService.verifyOtp(normalized, otp);

    let user = await prisma.user.findUnique({
      where: { phoneNumber: normalized },
      include: { profile: true },
    });

    const isNewUser = !user;

    if (!user) {
      user = await prisma.user.create({
        data: {
          phoneNumber: normalized,
          phoneVerified: true,
          status: 'PENDING_ONBOARDING',
        },
        include: { profile: true },
      });
    } else {
      user = await prisma.user.update({
        where: { id: user.id },
        data: { phoneVerified: true, lastActiveAt: new Date() },
        include: { profile: true },
      });
    }

    const tokens = this.generateTokens(user.id);

    // Store session in Redis
    const decoded = jwt.decode(tokens.accessToken) as any;
    await RedisSessionService.storeSession(decoded.jti, user.id, 24 * 3600);

    return { user, ...tokens, isNewUser };
  }

  /**
   * Refresh access token using refresh token
   */
  static async refreshToken(refreshToken: string): Promise<{ accessToken: string; refreshToken: string }> {
    try {
      const decoded = jwt.verify(refreshToken, env.JWT_REFRESH_SECRET) as { sub: string; type: string };

      if (decoded.type !== 'refresh') {
        throw new Error('Invalid token type');
      }

      const user = await prisma.user.findUnique({
        where: { id: decoded.sub },
      });

      if (!user || user.status === 'SUSPENDED' || user.status === 'DELETED') {
        throw new Error('User not found or inactive');
      }

      return this.generateTokens(user.id);
    } catch (error) {
      throw new Error('Invalid or expired refresh token');
    }
  }

  /**
   * Logout: revoke session
   */
  static async logout(accessToken: string): Promise<void> {
    try {
      const decoded = jwt.decode(accessToken) as any;
      if (decoded?.jti) {
        await RedisSessionService.revokeSession(decoded.jti);
      }
    } catch {
      // Silently fail logout
    }
  }

  private static generateTokens(userId: string): { accessToken: string; refreshToken: string } {
    const jti = `${Date.now()}-${Math.random().toString(36).substring(2, 15)}`;

    const accessToken = jwt.sign(
      { sub: userId, jti },
      env.JWT_SECRET,
      { expiresIn: '24h' }
    );

    const refreshToken = jwt.sign(
      { sub: userId, type: 'refresh', jti: `${jti}-refresh` },
      env.JWT_REFRESH_SECRET,
      { expiresIn: '30d' }
    );

    return { accessToken, refreshToken };
  }

  private static normalizePhone(phone: string): string {
    // Remove all non-digit characters except leading +
    let cleaned = phone.replace(/[^\d+]/g, '');
    if (!cleaned.startsWith('+')) {
      // Default to Kenya if no country code (customize per market)
      cleaned = '+254' + cleaned.replace(/^0/, '');
    }
    return cleaned;
  }
}
