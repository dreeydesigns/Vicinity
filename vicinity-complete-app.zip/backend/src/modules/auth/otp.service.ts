import { AfricaTalkingService } from '../../lib/atalking';
import { RedisSessionService } from '../../services/redis.service';

const MAX_OTP_ATTEMPTS = 3;
const OTP_RATE_LIMIT_WINDOW = 60; // seconds between requests
const OTP_RATE_LIMIT_MAX = 3; // max requests per window

export class OtpService {
  /**
   * Request OTP for phone number
   */
  static async requestOtp(phoneNumber: string): Promise<{ message: string; devOtp?: string }> {
    // Rate limit: max 3 OTP requests per 60 seconds per phone
    const rateLimitKey = `otp_rate:${phoneNumber}`;
    const allowed = await RedisSessionService.checkRateLimit(
      rateLimitKey,
      OTP_RATE_LIMIT_MAX,
      OTP_RATE_LIMIT_WINDOW
    );
    if (!allowed) {
      throw new Error('Too many OTP requests. Please wait 60 seconds.');
    }

    const otp = AfricaTalkingService.generateOtp();
    await RedisSessionService.storeOtp(phoneNumber, otp, 0);
    await AfricaTalkingService.sendOtp(phoneNumber, otp);

    const response: { message: string; devOtp?: string } = {
      message: 'OTP sent successfully',
    };

    // In development, return OTP for testing
    if (process.env.NODE_ENV === 'development') {
      response.devOtp = otp;
    }

    return response;
  }

  /**
   * Verify OTP
   */
  static async verifyOtp(phoneNumber: string, otp: string): Promise<boolean> {
    const stored = await RedisSessionService.getOtp(phoneNumber);
    if (!stored) {
      throw new Error('OTP expired or not found');
    }

    if (stored.attempts >= MAX_OTP_ATTEMPTS) {
      await RedisSessionService.deleteOtp(phoneNumber);
      throw new Error('Too many failed attempts. Request a new OTP.');
    }

    if (stored.otp !== otp) {
      await RedisSessionService.incrementOtpAttempt(phoneNumber);
      throw new Error('Invalid OTP');
    }

    await RedisSessionService.deleteOtp(phoneNumber);
    return true;
  }
}
