import { Router } from 'express';
import { SchedulerController } from './scheduler.controller';
import { authenticate } from '../../middleware/auth.middleware';

const router = Router();

router.use(authenticate);

router.post('/suggest', SchedulerController.generateSuggestions);
router.post('/select', SchedulerController.selectSuggestion);

export default router;
