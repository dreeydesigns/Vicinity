import { GoogleApiService } from '../../lib/google-apis';

interface TimeSlot {
  start: Date;
  end: Date;
}

interface FreeWindow {
  start: Date;
  end: Date;
  durationMinutes: number;
}

export class CalendarParserService {
  static readonly MIN_DATE_DURATION_MIN = 30;
  static readonly MAX_DATE_DURATION_MIN = 90;
  static readonly BUFFER_MIN_BEFORE = 15; // Buffer before date
  static readonly BUFFER_MIN_AFTER = 15;  // Buffer after date
  static readonly SEARCH_WINDOW_HOURS = 48; // Look ahead 48 hours

  /**
   * Find mutual free time slots between two users
   */
  static async findMutualFreeSlots(
    user1Id: string,
    user2Id: string,
    durationMinutes: number = 60
  ): Promise<FreeWindow[]> {
    const now = new Date();
    const timeMax = new Date(now.getTime() + this.SEARCH_WINDOW_HOURS * 60 * 60 * 1000);

    // Fetch free/busy for both users
    const [busy1, busy2] = await Promise.all([
      GoogleApiService.getFreeBusy(user1Id, now, timeMax),
      GoogleApiService.getFreeBusy(user2Id, now, timeMax),
    ]);

    const user1Email = Object.keys(busy1.calendars || {})[0] || 'primary';
    const user2Email = Object.keys(busy2.calendars || {})[0] || 'primary';

    const busySlots1 = busy1.calendars?.[user1Email]?.busy || [];
    const busySlots2 = busy2.calendars?.[user2Email]?.busy || [];

    // Convert to TimeSlot arrays
    const slots1: TimeSlot[] = busySlots1.map((b: any) => ({
      start: new Date(b.start!),
      end: new Date(b.end!),
    }));

    const slots2: TimeSlot[] = busySlots2.map((b: any) => ({
      start: new Date(b.start!),
      end: new Date(b.end!),
    }));

    // Merge busy slots from both users
    const mergedBusy = this.mergeTimeSlots([...slots1, ...slots2]);

    // Find free windows
    const freeWindows = this.findFreeWindows(mergedBusy, now, timeMax, durationMinutes);

    return freeWindows;
  }

  /**
   * Parse iCal/RRULE recurring events (fallback when freebusy is unavailable)
   */
  static async parseCalendarEvents(
    userId: string,
    daysAhead: number = 2
  ): Promise<TimeSlot[]> {
    const now = new Date();
    const timeMax = new Date(now.getTime() + daysAhead * 24 * 60 * 60 * 1000);

    const events = await GoogleApiService.listEvents(userId, now, timeMax);

    return events
      .filter((e) => e.start?.dateTime && e.end?.dateTime)
      .map((e) => ({
        start: new Date(e.start!.dateTime!),
        end: new Date(e.end!.dateTime!),
      }));
  }

  /**
   * Merge overlapping time slots
   */
  private static mergeTimeSlots(slots: TimeSlot[]): TimeSlot[] {
    if (slots.length === 0) return [];

    // Sort by start time
    const sorted = [...slots].sort((a, b) => a.start.getTime() - b.start.getTime());
    const merged: TimeSlot[] = [sorted[0]];

    for (let i = 1; i < sorted.length; i++) {
      const last = merged[merged.length - 1];
      const current = sorted[i];

      if (current.start <= last.end) {
        // Overlapping or adjacent, merge
        last.end = new Date(Math.max(last.end.getTime(), current.end.getTime()));
      } else {
        merged.push(current);
      }
    }

    return merged;
  }

  /**
   * Find free windows between busy slots
   */
  private static findFreeWindows(
    busySlots: TimeSlot[],
    searchStart: Date,
    searchEnd: Date,
    minDurationMinutes: number
  ): FreeWindow[] {
    const freeWindows: FreeWindow[] = [];
    let currentStart = new Date(searchStart);

    for (const busy of busySlots) {
      // Add buffer before busy slot
      const busyStart = new Date(busy.start.getTime() - this.BUFFER_MIN_BEFORE * 60 * 1000);
      const busyEnd = new Date(busy.end.getTime() + this.BUFFER_MIN_AFTER * 60 * 1000);

      if (busyStart > currentStart) {
        const durationMs = busyStart.getTime() - currentStart.getTime();
        const durationMin = durationMs / (60 * 1000);

        if (durationMin >= minDurationMinutes) {
          freeWindows.push({
            start: currentStart,
            end: busyStart,
            durationMinutes: Math.floor(durationMin),
          });
        }
      }

      currentStart = new Date(Math.max(currentStart.getTime(), busyEnd.getTime()));
    }

    // Check after last busy slot
    if (currentStart < searchEnd) {
      const durationMs = searchEnd.getTime() - currentStart.getTime();
      const durationMin = durationMs / (60 * 1000);

      if (durationMin >= minDurationMinutes) {
        freeWindows.push({
          start: currentStart,
          end: searchEnd,
          durationMinutes: Math.floor(durationMin),
        });
      }
    }

    return freeWindows;
  }

  /**
   * Suggest optimal date duration based on time of day and available window
   */
  static suggestDuration(freeWindow: FreeWindow): number {
    const hour = freeWindow.start.getHours();

    // Coffee dates: 30-45 min (morning/afternoon)
    if (hour >= 8 && hour < 17) {
      return Math.min(45, freeWindow.durationMinutes);
    }

    // Dinner/drinks: 60-90 min (evening)
    if (hour >= 17 && hour < 22) {
      return Math.min(90, freeWindow.durationMinutes);
    }

    // Late night: 30 min max
    return Math.min(30, freeWindow.durationMinutes);
  }

  /**
   * Check if a specific time slot is free for both users
   */
  static async isTimeSlotFree(
    user1Id: string,
    user2Id: string,
    start: Date,
    end: Date
  ): Promise<boolean> {
    const [busy1, busy2] = await Promise.all([
      GoogleApiService.getFreeBusy(user1Id, start, end),
      GoogleApiService.getFreeBusy(user2Id, start, end),
    ]);

    const user1Email = Object.keys(busy1.calendars || {})[0] || 'primary';
    const user2Email = Object.keys(busy2.calendars || {})[0] || 'primary';

    const busySlots1 = busy1.calendars?.[user1Email]?.busy || [];
    const busySlots2 = busy2.calendars?.[user2Email]?.busy || [];

    return busySlots1.length === 0 && busySlots2.length === 0;
  }
}
