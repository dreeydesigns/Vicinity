import axios from 'axios';

interface VenueSearchParams {
  latitude: number;
  longitude: number;
  radiusMeters?: number;
  type?: string;
  minRating?: number;
  maxPriceLevel?: number;
  openNow?: boolean;
}

interface Venue {
  placeId: string;
  name: string;
  address: string;
  latitude: number;
  longitude: number;
  rating?: number;
  priceLevel?: number;
  photoReference?: string;
  types: string[];
  distanceM: number;
}

export class VenueService {
  static readonly DEFAULT_RADIUS = 500; // meters
  static readonly GOOGLE_PLACES_API = 'https://maps.googleapis.com/maps/api/place/nearbysearch/json';
  static readonly GOOGLE_PLACE_DETAILS_API = 'https://maps.googleapis.com/maps/api/place/details/json';

  private static getApiKey(): string {
    return process.env.GOOGLE_PLACES_API_KEY || process.env.GOOGLE_CLIENT_ID || '';
  }

  /**
   * Find date venues near a midpoint between two users
   */
  static async findMidpointVenues(
    lat1: number,
    lon1: number,
    lat2: number,
    lon2: number,
    preferences: {
      venueTypes?: string[];
      minRating?: number;
      maxPriceLevel?: number;
    } = {}
  ): Promise<Venue[]> {
    // Calculate midpoint
    const midpointLat = (lat1 + lat2) / 2;
    const midpointLon = (lon1 + lon2) / 2;

    // Search radius based on distance between users
    const distanceBetween = this.haversineDistance(lat1, lon1, lat2, lon2);
    const searchRadius = Math.max(distanceBetween * 0.4, 200); // 40% of distance, min 200m

    const venueTypes = preferences.venueTypes || ['cafe', 'restaurant', 'bar'];
    const allVenues: Venue[] = [];

    for (const type of venueTypes) {
      const venues = await this.searchGooglePlaces({
        latitude: midpointLat,
        longitude: midpointLon,
        radiusMeters: Math.min(searchRadius, 1000),
        type,
        minRating: preferences.minRating || 4.0,
        maxPriceLevel: preferences.maxPriceLevel || 3,
        openNow: true,
      });
      allVenues.push(...venues);
    }

    // Deduplicate by placeId
    const seen = new Set<string>();
    const unique = allVenues.filter((v) => {
      if (seen.has(v.placeId)) return false;
      seen.add(v.placeId);
      return true;
    });

    // Sort by composite score (rating * distance_factor)
    return unique
      .map((v) => ({
        ...v,
        score: this.calculateVenueScore(v, midpointLat, midpointLon, lat1, lon1, lat2, lon2),
      }))
      .sort((a, b) => b.score - a.score)
      .slice(0, 5); // Top 5 suggestions
  }

  /**
   * Search Google Places API
   */
  private static async searchGooglePlaces(params: VenueSearchParams): Promise<Venue[]> {
    try {
      const response = await axios.get(this.GOOGLE_PLACES_API, {
        params: {
          location: `${params.latitude},${params.longitude}`,
          radius: params.radiusMeters || this.DEFAULT_RADIUS,
          type: params.type,
          minprice: 0,
          maxprice: params.maxPriceLevel || 4,
          opennow: params.openNow || false,
          key: this.getApiKey(),
        },
      });

      const results = response.data.results || [];

      return results
        .filter((r: any) => !params.minRating || r.rating >= params.minRating)
        .map((r: any) => ({
          placeId: r.place_id,
          name: r.name,
          address: r.vicinity || r.formatted_address || '',
          latitude: r.geometry.location.lat,
          longitude: r.geometry.location.lng,
          rating: r.rating,
          priceLevel: r.price_level,
          photoReference: r.photos?.[0]?.photo_reference,
          types: r.types || [],
          distanceM: this.haversineDistance(
            params.latitude,
            params.longitude,
            r.geometry.location.lat,
            r.geometry.location.lng
          ),
        }));
    } catch (error) {
      console.error('Google Places API error:', error);
      return [];
    }
  }

  /**
   * Get place details (photos, reviews, etc.)
   */
  static async getPlaceDetails(placeId: string): Promise<any> {
    try {
      const response = await axios.get(this.GOOGLE_PLACE_DETAILS_API, {
        params: {
          place_id: placeId,
          fields: 'name,formatted_address,photo,rating,price_level,opening_hours,website,formatted_phone_number',
          key: this.getApiKey(),
        },
      });
      return response.data.result;
    } catch (error) {
      console.error('Place details error:', error);
      return null;
    }
  }

  /**
   * Calculate venue score based on rating, distance fairness, and relevance
   */
  private static calculateVenueScore(
    venue: Venue,
    midpointLat: number,
    midpointLon: number,
    user1Lat: number,
    user1Lon: number,
    user2Lat: number,
    user2Lon: number
  ): number {
    const ratingScore = (venue.rating || 3.5) / 5; // Normalize to 0-1

    const distFromUser1 = this.haversineDistance(user1Lat, user1Lon, venue.latitude, venue.longitude);
    const distFromUser2 = this.haversineDistance(user2Lat, user2Lon, venue.latitude, venue.longitude);
    const distFromMidpoint = this.haversineDistance(midpointLat, midpointLon, venue.latitude, venue.longitude);

    // Fairness: prefer venues equidistant from both users
    const fairnessScore = 1 - Math.abs(distFromUser1 - distFromUser2) / Math.max(distFromUser1 + distFromUser2, 1);

    // Closeness: prefer venues close to midpoint
    const closenessScore = 1 / (1 + distFromMidpoint / 500);

    // Price preference (lower price = higher score for first dates)
    const priceScore = 1 - ((venue.priceLevel || 2) / 4);

    return ratingScore * 0.35 + fairnessScore * 0.3 + closenessScore * 0.2 + priceScore * 0.15;
  }

  /**
   * Haversine distance between two coordinates in meters
   */
  private static haversineDistance(lat1: number, lon1: number, lat2: number, lon2: number): number {
    const R = 6371000; // Earth radius in meters
    const dLat = this.toRadians(lat2 - lat1);
    const dLon = this.toRadians(lon2 - lon1);
    const a =
      Math.sin(dLat / 2) * Math.sin(dLat / 2) +
      Math.cos(this.toRadians(lat1)) * Math.cos(this.toRadians(lat2)) *
      Math.sin(dLon / 2) * Math.sin(dLon / 2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    return R * c;
  }

  private static toRadians(degrees: number): number {
    return degrees * (Math.PI / 180);
  }
}
