import { CalendarParserService } from './calendar-parser.service';
import { VenueService } from './venue.service';
import { prisma } from '../../lib/prisma';
import { MatchService } from '../match/match.service';
import { PushService } from '../notification/push.service';

interface ScheduleDateInput {
  matchId: string;
  userId: string;
}

interface DateSuggestion {
  venue: {
    placeId: string;
    name: string;
    address: string;
    latitude: number;
    longitude: number;
    rating?: number;
    priceLevel?: number;
    venueType: string;
  };
  timeSlot: {
    start: Date;
    end: Date;
  };
  rationale: string;
}

export class SchedulerService {
  /**
   * Auto-schedule a date for a match
   * 1. Find mutual free time slots
   * 2. Find midpoint venues
   * 3. Rank combinations
   * 4. Return top 3 suggestions
   */
  static async generateDateSuggestions(matchId: string): Promise<DateSuggestion[]> {
    const match = await prisma.match.findUnique({
      where: { id: matchId },
      include: {
        user1: { include: { profile: true } },
        user2: { include: { profile: true } },
      },
    });

    if (!match) throw new Error('Match not found');
    if (match.status !== 'ACCEPTED') throw new Error('Match must be accepted before scheduling');

    // Get user locations
    const [loc1, loc2] = await Promise.all([
      prisma.userLocation.findFirst({
        where: { userId: match.user1Id },
        orderBy: { gpsLastSeenAt: 'desc' },
      }),
      prisma.userLocation.findFirst({
        where: { userId: match.user2Id },
        orderBy: { gpsLastSeenAt: 'desc' },
      }),
    ]);

    if (!loc1 || !loc2) {
      throw new Error('Location data unavailable for one or both users');
    }

    // Find mutual free slots
    const freeSlots = await CalendarParserService.findMutualFreeSlots(
      match.user1Id,
      match.user2Id,
      60
    );

    if (freeSlots.length === 0) {
      throw new Error('No mutual free time slots found in the next 48 hours');
    }

    // Find venues near midpoint
    const venues = await VenueService.findMidpointVenues(
      loc1.latitude,
      loc1.longitude,
      loc2.latitude,
      loc2.longitude,
      {
        venueTypes: this.inferVenueTypes(match.user1.profile?.interests, match.user2.profile?.interests),
        minRating: 4.0,
        maxPriceLevel: 2,
      }
    );

    if (venues.length === 0) {
      throw new Error('No suitable venues found near your locations');
    }

    // Generate suggestions: pair top venues with best time slots
    const suggestions: DateSuggestion[] = [];
    const usedSlots = new Set<number>();

    for (const venue of venues.slice(0, 3)) {
      // Find the best unused slot for this venue
      for (let i = 0; i < freeSlots.length; i++) {
        if (usedSlots.has(i)) continue;

        const slot = freeSlots[i];
        const duration = CalendarParserService.suggestDuration(slot);
        const endTime = new Date(slot.start.getTime() + duration * 60 * 1000);

        suggestions.push({
          venue: {
            placeId: venue.placeId,
            name: venue.name,
            address: venue.address,
            latitude: venue.latitude,
            longitude: venue.longitude,
            rating: venue.rating,
            priceLevel: venue.priceLevel,
            venueType: venue.types[0] || 'cafe',
          },
          timeSlot: {
            start: slot.start,
            end: endTime,
          },
          rationale: this.generateRationale(venue, slot, match),
        });

        usedSlots.add(i);
        break;
      }
    }

    // Persist suggestions to database
    for (const suggestion of suggestions) {
      await prisma.dateSuggestion.create({
        data: {
          matchId,
          placeId: suggestion.venue.placeId,
          name: suggestion.venue.name,
          address: suggestion.venue.address,
          latitude: suggestion.venue.latitude,
          longitude: suggestion.venue.longitude,
          rating: suggestion.venue.rating,
          priceLevel: suggestion.venue.priceLevel,
          venueType: suggestion.venue.venueType.toUpperCase() as any,
          rationale: suggestion.rationale,
          distanceFromUser1M: VenueService['haversineDistance'](
            loc1.latitude, loc1.longitude,
            suggestion.venue.latitude, suggestion.venue.longitude
          ),
          distanceFromUser2M: VenueService['haversineDistance'](
            loc2.latitude, loc2.longitude,
            suggestion.venue.latitude, suggestion.venue.longitude
          ),
          proposedStartAt: suggestion.timeSlot.start,
          proposedEndAt: suggestion.timeSlot.end,
        },
      });
    }

    // Update match status
    await MatchService.updateMatchStatus(matchId, 'PENDING_SCHEDULE');

    // Notify users
    await PushService.sendNotification(match.user1Id, {
      title: 'Date Suggestions Ready',
      body: `We found ${suggestions.length} great spots for your date!`,
      data: { matchId, type: 'DATE_SUGGESTIONS' },
    });
    await PushService.sendNotification(match.user2Id, {
      title: 'Date Suggestions Ready',
      body: `We found ${suggestions.length} great spots for your date!`,
      data: { matchId, type: 'DATE_SUGGESTIONS' },
    });

    return suggestions;
  }

  /**
   * User selects a date suggestion
   */
  static async selectDateSuggestion(matchId: string, suggestionId: string, userId: string): Promise<any> {
    const suggestion = await prisma.dateSuggestion.findUnique({
      where: { id: suggestionId },
      include: { match: true },
    });

    if (!suggestion || suggestion.matchId !== matchId) {
      throw new Error('Suggestion not found');
    }

    const isUser1 = suggestion.match.user1Id === userId;

    await prisma.dateSuggestion.update({
      where: { id: suggestionId },
      data: isUser1 ? { selectedByUser1: true } : { selectedByUser2: true },
    });

    // Check if both selected
    const updated = await prisma.dateSuggestion.findUnique({
      where: { id: suggestionId },
    });

    if (updated?.selectedByUser1 && updated?.selectedByUser2) {
      // Both agreed, finalize the date
      await MatchService.updateMatchStatus(matchId, 'SCHEDULED', {
        scheduledAt: suggestion.proposedStartAt,
        venueId: suggestion.placeId,
        venueName: suggestion.name,
        venueAddress: suggestion.address,
        venueLatitude: suggestion.latitude,
        venueLongitude: suggestion.longitude,
        venueType: suggestion.venueType,
      });

      await PushService.sendNotification(suggestion.match.user1Id, {
        title: 'Date Confirmed!',
        body: `Meet at ${suggestion.name} at ${suggestion.proposedStartAt.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}`,
        data: { matchId, type: 'DATE_CONFIRMED' },
      });
      await PushService.sendNotification(suggestion.match.user2Id, {
        title: 'Date Confirmed!',
        body: `Meet at ${suggestion.name} at ${suggestion.proposedStartAt.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}`,
        data: { matchId, type: 'DATE_CONFIRMED' },
      });
    }

    return updated;
  }

  private static inferVenueTypes(interests1?: string[], interests2?: string[]): string[] {
    const all = [...(interests1 || []), ...(interests2 || [])].map((i) => i.toLowerCase());
    const types: string[] = ['cafe'];

    if (all.some((i) => ['wine', 'cocktail', 'bar', 'nightlife'].includes(i))) types.push('bar');
    if (all.some((i) => ['food', 'dining', 'restaurant', 'sushi', 'pizza'].includes(i))) types.push('restaurant');
    if (all.some((i) => ['nature', 'park', 'hiking', 'outdoor'].includes(i))) types.push('park');
    if (all.some((i) => ['art', 'museum', 'culture', 'gallery'].includes(i))) types.push('museum');
    if (all.some((i) => ['book', 'reading', 'library'].includes(i))) types.push('book_store');

    return [...new Set(types)];
  }

  private static generateRationale(venue: any, slot: any, match: any): string {
    const hour = slot.start.getHours();
    let timeOfDay = 'afternoon';
    if (hour < 12) timeOfDay = 'morning';
    else if (hour >= 17) timeOfDay = 'evening';

    const interests1 = match.user1.profile?.interests || [];
    const interests2 = match.user2.profile?.interests || [];
    const shared = interests1.filter((i: string) => interests2.includes(i));

    let rationale = `Perfect for a ${timeOfDay} date`;
    if (shared.length > 0) {
      rationale += `. You both love ${shared.slice(0, 2).join(' and ')}`;
    }
    if (venue.rating && venue.rating >= 4.5) {
      rationale += '. Highly rated spot';
    }

    return rationale;
  }
}
