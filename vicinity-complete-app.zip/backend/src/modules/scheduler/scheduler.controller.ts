import { Request, Response, NextFunction } from 'express';
import { SchedulerService } from './scheduler.service';
import { z } from 'zod';

const suggestSchema = z.object({
  matchId: z.string().cuid(),
});

const selectSchema = z.object({
  matchId: z.string().cuid(),
  suggestionId: z.string().cuid(),
});

export class SchedulerController {
  static async generateSuggestions(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const { matchId } = suggestSchema.parse(req.body);
      const suggestions = await SchedulerService.generateDateSuggestions(matchId);
      res.status(200).json({ suggestions });
    } catch (error) {
      next(error);
    }
  }

  static async selectSuggestion(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const userId = (req as any).user.id;
      const { matchId, suggestionId } = selectSchema.parse(req.body);
      const result = await SchedulerService.selectDateSuggestion(matchId, suggestionId, userId);
      res.status(200).json(result);
    } catch (error) {
      next(error);
    }
  }
}
