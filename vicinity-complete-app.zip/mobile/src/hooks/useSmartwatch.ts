import { useEffect, useCallback } from 'react';
import { Platform, Vibration } from 'react-native';

// Watch connectivity imports (conditional for platform)
let WatchConnectivity: any = null;
if (Platform.OS === 'ios') {
  try {
    WatchConnectivity = require('react-native-watch-connectivity').default;
  } catch {
    // Watch connectivity not available
  }
}

export const useSmartwatch = () => {
  const isWatchAvailable = Platform.OS === 'ios' && WatchConnectivity !== null;

  useEffect(() => {
    if (!isWatchAvailable) return;

    // Listen for messages from watch
    const unsubscribe = WatchConnectivity?.subscribeToMessages?.((message: any) => {
      console.log('Message from watch:', message);
    });

    return () => {
      unsubscribe?.();
    };
  }, [isWatchAvailable]);

  /**
   * Send haptic trigger to smartwatch
   */
  const sendWatchHaptic = useCallback(
    async (type: 'MATCH_BUZZ' | 'DATE_REMINDER' | 'WALLET_UNLOCK' | 'SAFETY_ALERT') => {
      if (!isWatchAvailable) return;

      const patterns: Record<string, number[]> = {
        MATCH_BUZZ: [0, 200, 100, 200, 100, 400],
        DATE_REMINDER: [0, 100, 50, 100],
        WALLET_UNLOCK: [0, 300],
        SAFETY_ALERT: [0, 500, 200, 500, 200, 500],
      };

      try {
        await WatchConnectivity?.sendMessage?.({
          type: 'haptic',
          pattern: patterns[type] || patterns.MATCH_BUZZ,
          hapticType: type,
        });
      } catch (error) {
        console.error('Watch haptic error:', error);
      }
    },
    [isWatchAvailable]
  );

  /**
   * Trigger phone vibration (fallback when no watch)
   */
  const triggerPhoneVibration = useCallback((type: string) => {
    const patterns: Record<string, number[]> = {
      MATCH_BUZZ: [0, 200, 100, 200, 100, 400],
      DATE_REMINDER: [0, 100, 50, 100],
      WALLET_UNLOCK: [0, 300],
      SAFETY_ALERT: [0, 500, 200, 500, 200, 500],
    };

    Vibration.vibrate(patterns[type] || patterns.MATCH_BUZZ);
  }, []);

  /**
   * Send match data to watch for display
   */
  const sendMatchToWatch = useCallback(
    async (matchData: {
      matchId: string;
      displayName: string;
      compatibilityScore: number;
      venueName?: string;
      time?: string;
    }) => {
      if (!isWatchAvailable) return;

      try {
        await WatchConnectivity?.sendMessage?.({
          type: 'match_update',
          data: matchData,
        });
      } catch (error) {
        console.error('Watch send error:', error);
      }
    },
    [isWatchAvailable]
  );

  return {
    isWatchAvailable,
    sendWatchHaptic,
    triggerPhoneVibration,
    sendMatchToWatch,
  };
};
