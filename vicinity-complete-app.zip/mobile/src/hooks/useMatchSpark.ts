import { useEffect, useCallback } from 'react';
import { useMatchContext } from '../context/MatchContext';
import apiClient from '../api/client';
import * as Notifications from 'expo-notifications';

export const useMatchSpark = () => {
  const { addMatch, currentMatch, setCurrentMatch } = useMatchContext();

  const handleNotification = useCallback(
    async (notification: Notifications.Notification) => {
      const data = notification.request.content.data;

      if (data?.type === 'MATCH_NEARBY') {
        // Fetch match details
        try {
          const response = await apiClient.get(`/matches/${data.matchId}`);
          const match = response.data.match;

          const otherUser = match.user1Id === data.userId ? match.user2 : match.user1;

          addMatch({
            id: match.id,
            status: match.status,
            compatibilityScore: match.compatibilityScore,
            otherUser: {
              id: otherUser.id,
              displayName: otherUser.profile?.displayName || 'Someone',
              photos: otherUser.profile?.photos || [],
              bio: otherUser.profile?.bio,
            },
            expiresAt: new Date(match.expiresAt),
          });

          setCurrentMatch({
            id: match.id,
            status: match.status,
            compatibilityScore: match.compatibilityScore,
            otherUser: {
              id: otherUser.id,
              displayName: otherUser.profile?.displayName || 'Someone',
              photos: otherUser.profile?.photos || [],
              bio: otherUser.profile?.bio,
            },
            expiresAt: new Date(match.expiresAt),
          });
        } catch (error) {
          console.error('Failed to fetch match details:', error);
        }
      }
    },
    [addMatch, setCurrentMatch]
  );

  useEffect(() => {
    const subscription = Notifications.addNotificationReceivedListener(handleNotification);
    return () => subscription.remove();
  }, [handleNotification]);

  const giveConsent = useCallback(
    async (matchId: string): Promise<boolean> => {
      try {
        const response = await apiClient.post('/matches/consent', { matchId });
        return response.data.bothConsented;
      } catch (error) {
        console.error('Consent failed:', error);
        return false;
      }
    },
    []
  );

  return { currentMatch, giveConsent };
};
