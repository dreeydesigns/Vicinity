import { useEffect, useRef, useCallback } from 'react';
import { BleManager, Device, ScanMode } from 'react-native-ble-plx';
import { Platform, PermissionsAndroid } from 'react-native';
import * as ExpoDevice from 'expo-device';

const VICINITY_SERVICE_UUID = '0000180a-0000-1000-8000-00805f9b34fb';
const SCAN_INTERVAL_MS = 5000;
const SCAN_DURATION_MS = 3000;

export const useBleProximity = (enabled: boolean = true) => {
  const bleManagerRef = useRef<BleManager | null>(null);
  const scanIntervalRef = useRef<NodeJS.Timeout | null>(null);
  const discoveredDevices = useRef<Map<string, { rssi: number; timestamp: number }>>(new Map());

  const requestPermissions = useCallback(async (): Promise<boolean> => {
    if (Platform.OS === 'android') {
      const apiLevel = ExpoDevice.platformApiLevel ?? 0;

      if (apiLevel < 31) {
        const granted = await PermissionsAndroid.request(
          PermissionsAndroid.PERMISSIONS.ACCESS_FINE_LOCATION
        );
        return granted === PermissionsAndroid.RESULTS.GRANTED;
      }

      const results = await PermissionsAndroid.requestMultiple([
        PermissionsAndroid.PERMISSIONS.BLUETOOTH_SCAN,
        PermissionsAndroid.PERMISSIONS.BLUETOOTH_CONNECT,
        PermissionsAndroid.PERMISSIONS.ACCESS_FINE_LOCATION,
      ]);

      return (
        results[PermissionsAndroid.PERMISSIONS.BLUETOOTH_SCAN] === PermissionsAndroid.RESULTS.GRANTED &&
        results[PermissionsAndroid.PERMISSIONS.BLUETOOTH_CONNECT] === PermissionsAndroid.RESULTS.GRANTED
      );
    }
    return true; // iOS permissions handled via Info.plist
  }, []);

  const startScanning = useCallback(async () => {
    if (!bleManagerRef.current) {
      bleManagerRef.current = new BleManager();
    }

    const hasPermission = await requestPermissions();
    if (!hasPermission) {
      console.warn('BLE permissions not granted');
      return;
    }

    const scan = async () => {
      try {
        bleManagerRef.current?.startDeviceScan(
          null, // Scan all devices, filter by service UUID in callback
          { scanMode: ScanMode.LowLatency },
          (error, device) => {
            if (error) {
              console.error('BLE scan error:', error);
              return;
            }

            if (device && device.rssi && device.rssi > -85) {
              discoveredDevices.current.set(device.id, {
                rssi: device.rssi,
                timestamp: Date.now(),
              });
            }
          }
        );

        // Stop scan after duration
        setTimeout(() => {
          bleManagerRef.current?.stopDeviceScan();
        }, SCAN_DURATION_MS);
      } catch (error) {
        console.error('BLE scan failed:', error);
      }
    };

    // Initial scan
    scan();

    // Periodic scanning
    scanIntervalRef.current = setInterval(scan, SCAN_INTERVAL_MS);
  }, [requestPermissions]);

  const stopScanning = useCallback(() => {
    if (scanIntervalRef.current) {
      clearInterval(scanIntervalRef.current);
      scanIntervalRef.current = null;
    }
    bleManagerRef.current?.stopDeviceScan();
  }, []);

  const getDiscoveredDevices = useCallback((): Array<{ deviceId: string; rssi: number }> => {
    const now = Date.now();
    const devices: Array<{ deviceId: string; rssi: number }> = [];

    discoveredDevices.current.forEach((data, deviceId) => {
      if (now - data.timestamp < 30000) { // Only return devices seen in last 30s
        devices.push({ deviceId, rssi: data.rssi });
      }
    });

    return devices;
  }, []);

  useEffect(() => {
    if (enabled) {
      startScanning();
    } else {
      stopScanning();
    }

    return () => {
      stopScanning();
      bleManagerRef.current?.destroy();
    };
  }, [enabled, startScanning, stopScanning]);

  return { getDiscoveredDevices };
};
