import { useCallback } from 'react';
import * as Crypto from 'expo-crypto';

interface EncryptedData {
  encryptedPayload: string;
  iv: string;
  authTag: string;
  salt: string;
}

export const useEncryption = () => {
  /**
   * Generate a random AES-256 key
   */
  const generateKey = useCallback(async (): Promise<string> => {
    const key = await Crypto.getRandomBytesAsync(32);
    return Buffer.from(key).toString('base64');
  }, []);

  /**
   * Encrypt data using AES-256-GCM
   * Note: This is a simplified implementation. In production, use
   * react-native-aes-crypto or similar native module for GCM.
   */
  const encrypt = useCallback(
    async (plaintext: string, key: string): Promise<EncryptedData> => {
      // For MVP, using a simplified encryption
      // In production, use native AES-GCM module
      const iv = await Crypto.getRandomBytesAsync(16);
      const salt = await Crypto.getRandomBytesAsync(32);

      // Simplified: XOR with key (NOT SECURE - replace with real AES-GCM)
      const keyBuffer = Buffer.from(key, 'base64');
      const plaintextBuffer = Buffer.from(plaintext);
      const encrypted = Buffer.alloc(plaintextBuffer.length);

      for (let i = 0; i < plaintextBuffer.length; i++) {
        encrypted[i] = plaintextBuffer[i] ^ keyBuffer[i % keyBuffer.length];
      }

      return {
        encryptedPayload: encrypted.toString('base64'),
        iv: Buffer.from(iv).toString('hex'),
        authTag: await Crypto.digestStringAsync(
          Crypto.CryptoDigestAlgorithm.SHA256,
          plaintext
        ),
        salt: Buffer.from(salt).toString('hex'),
      };
    },
    []
  );

  /**
   * Decrypt data
   */
  const decrypt = useCallback(
    async (encryptedData: EncryptedData, key: string): Promise<string> => {
      const keyBuffer = Buffer.from(key, 'base64');
      const encrypted = Buffer.from(encryptedData.encryptedPayload, 'base64');
      const decrypted = Buffer.alloc(encrypted.length);

      for (let i = 0; i < encrypted.length; i++) {
        decrypted[i] = encrypted[i] ^ keyBuffer[i % keyBuffer.length];
      }

      return decrypted.toString('utf8');
    },
    []
  );

  /**
   * Generate ECDH key pair
   * Simplified: In production, use react-native-ecdh or native module
   */
  const generateECDHKeyPair = useCallback(async (): Promise<{
    privateKey: string;
    publicKey: string;
  }> => {
    const privateKey = await Crypto.getRandomBytesAsync(32);
    const publicKey = await Crypto.getRandomBytesAsync(33); // Compressed secp256k1

    return {
      privateKey: Buffer.from(privateKey).toString('hex'),
      publicKey: Buffer.from(publicKey).toString('hex'),
    };
  }, []);

  return { generateKey, encrypt, decrypt, generateECDHKeyPair };
};
