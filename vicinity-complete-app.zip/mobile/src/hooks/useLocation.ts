import { useEffect, useRef, useState, useCallback } from 'react';
import * as Location from 'expo-location';
import * as TaskManager from 'expo-task-manager';

const LOCATION_TASK_NAME = 'vicinity-background-location';

interface LocationData {
  latitude: number;
  longitude: number;
  accuracy: number | null;
  timestamp: number;
}

export const useLocation = () => {
  const [location, setLocation] = useState<LocationData | null>(null);
  const [hasPermission, setHasPermission] = useState<boolean>(false);
  const locationSubscription = useRef<Location.LocationSubscription | null>(null);

  const requestPermission = useCallback(async (): Promise<boolean> => {
    const { status: foregroundStatus } = await Location.requestForegroundPermissionsAsync();
    if (foregroundStatus !== 'granted') {
      setHasPermission(false);
      return false;
    }

    const { status: backgroundStatus } = await Location.requestBackgroundPermissionsAsync();
    setHasPermission(backgroundStatus === 'granted');
    return backgroundStatus === 'granted';
  }, []);

  const startTracking = useCallback(async () => {
    const permitted = await requestPermission();
    if (!permitted) return;

    // Foreground tracking
    locationSubscription.current = await Location.watchPositionAsync(
      {
        accuracy: Location.Accuracy.Balanced,
        timeInterval: 30000, // 30 seconds
        distanceInterval: 50, // 50 meters
      },
      (loc) => {
        setLocation({
          latitude: loc.coords.latitude,
          longitude: loc.coords.longitude,
          accuracy: loc.coords.accuracy,
          timestamp: loc.timestamp,
        });
      }
    );

    // Background tracking
    await Location.startLocationUpdatesAsync(LOCATION_TASK_NAME, {
      accuracy: Location.Accuracy.Balanced,
      timeInterval: 120000, // 2 minutes
      distanceInterval: 100, // 100 meters
      foregroundService: {
        notificationTitle: 'Vicinity is active',
        notificationBody: 'Finding matches nearby...',
      },
      pausesUpdatesAutomatically: true,
      activityType: Location.ActivityType.Fitness,
    });
  }, [requestPermission]);

  const stopTracking = useCallback(async () => {
    locationSubscription.current?.remove();
    locationSubscription.current = null;

    const isRegistered = await TaskManager.isTaskRegisteredAsync(LOCATION_TASK_NAME);
    if (isRegistered) {
      await Location.stopLocationUpdatesAsync(LOCATION_TASK_NAME);
    }
  }, []);

  useEffect(() => {
    return () => {
      stopTracking();
    };
  }, [stopTracking]);

  return {
    location,
    hasPermission,
    requestPermission,
    startTracking,
    stopTracking,
  };
};

// Background location task handler
TaskManager.defineTask(LOCATION_TASK_NAME, ({ data, error }: any) => {
  if (error) {
    console.error('Background location error:', error);
    return;
  }

  if (data) {
    const { locations } = data;
    // Send to server via background fetch or stored for next foreground
    console.log('Background location update:', locations);
  }
});
