import { Platform, Vibration } from 'react-native';

let WatchConnectivity: any = null;
if (Platform.OS === 'ios') {
  try {
    WatchConnectivity = require('react-native-watch-connectivity').default;
  } catch {
    // Not available
  }
}

export const isWatchSupported = (): boolean => {
  return Platform.OS === 'ios' && WatchConnectivity !== null;
};

export const sendHapticToWatch = async (type: string): Promise<void> => {
  if (!isWatchSupported()) return;

  try {
    await WatchConnectivity.sendMessage({
      type: 'haptic',
      hapticType: type,
    });
  } catch (error) {
    console.error('Watch haptic error:', error);
  }
};

export const sendMatchUpdateToWatch = async (matchData: any): Promise<void> => {
  if (!isWatchSupported()) return;

  try {
    await WatchConnectivity.sendMessage({
      type: 'match_update',
      data: matchData,
    });
  } catch (error) {
    console.error('Watch update error:', error);
  }
};

export const triggerPhoneHaptic = (pattern: number[]): void => {
  Vibration.vibrate(pattern);
};
