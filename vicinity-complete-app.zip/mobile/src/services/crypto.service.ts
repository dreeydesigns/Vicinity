import * as Crypto from 'expo-crypto';

export const generateSecureRandom = async (length: number): Promise<Uint8Array> => {
  return await Crypto.getRandomBytesAsync(length);
};

export const sha256 = async (data: string): Promise<string> => {
  return await Crypto.digestStringAsync(Crypto.CryptoDigestAlgorithm.SHA256, data);
};

export const generateUUID = (): string => {
  return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, (c) => {
    const r = (Math.random() * 16) | 0;
    const v = c === 'x' ? r : (r & 0x3) | 0x8;
    return v.toString(16);
  });
};
