import * as Calendar from 'expo-calendar';

export const requestCalendarPermissions = async (): Promise<boolean> => {
  const { status } = await Calendar.requestCalendarPermissionsAsync();
  return status === 'granted';
};

export const getCalendars = async (): Promise<Calendar.Calendar[]> => {
  const calendars = await Calendar.getCalendarsAsync(Calendar.EntityTypes.EVENT);
  return calendars;
};

export const getEvents = async (
  calendarId: string,
  startDate: Date,
  endDate: Date
): Promise<Calendar.Event[]> => {
  const events = await Calendar.getEventsAsync([calendarId], startDate, endDate);
  return events;
};
