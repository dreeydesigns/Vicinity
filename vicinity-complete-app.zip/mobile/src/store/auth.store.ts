import { create } from 'zustand';
import AsyncStorage from '@react-native-async-storage/async-storage';

interface AuthState {
  accessToken: string | null;
  refreshToken: string | null;
  user: any | null;
  setAuth: (accessToken: string, refreshToken: string, user: any) => void;
  clearAuth: () => void;
  loadAuth: () => Promise<void>;
}

export const useAuthStore = create<AuthState>((set) => ({
  accessToken: null,
  refreshToken: null,
  user: null,

  setAuth: (accessToken, refreshToken, user) => {
    AsyncStorage.setItem('accessToken', accessToken);
    AsyncStorage.setItem('refreshToken', refreshToken);
    AsyncStorage.setItem('user', JSON.stringify(user));
    set({ accessToken, refreshToken, user });
  },

  clearAuth: () => {
    AsyncStorage.multiRemove(['accessToken', 'refreshToken', 'user']);
    set({ accessToken: null, refreshToken: null, user: null });
  },

  loadAuth: async () => {
    const [accessToken, refreshToken, userStr] = await AsyncStorage.multiGet([
      'accessToken',
      'refreshToken',
      'user',
    ]);
    if (accessToken[1] && userStr[1]) {
      set({
        accessToken: accessToken[1],
        refreshToken: refreshToken[1],
        user: JSON.parse(userStr[1]),
      });
    }
  },
}));
