import { create } from 'zustand';

interface MatchState {
  activeMatchId: string | null;
  matchCountdown: number; // seconds remaining
  setActiveMatch: (matchId: string | null) => void;
  setCountdown: (seconds: number) => void;
  decrementCountdown: () => void;
}

export const useMatchStore = create<MatchState>((set) => ({
  activeMatchId: null,
  matchCountdown: 900, // 15 minutes default

  setActiveMatch: (matchId) => set({ activeMatchId: matchId }),
  setCountdown: (seconds) => set({ matchCountdown: seconds }),
  decrementCountdown: () =>
    set((state) => ({
      matchCountdown: Math.max(0, state.matchCountdown - 1),
    })),
}));
