import React, { useEffect } from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { useAuth } from '../context/AuthContext';
import PhoneEntryScreen from '../screens/auth/PhoneEntryScreen';
import OtpVerifyScreen from '../screens/auth/OtpVerifyScreen';
import HomeScreen from '../screens/main/HomeScreen';
import SparkScreen from '../screens/main/SparkScreen';
import DateConfirmScreen from '../screens/main/DateConfirmScreen';
import WalletScreen from '../screens/main/WalletScreen';

export type RootStackParamList = {
  PhoneEntry: undefined;
  OtpVerify: { phoneNumber: string };
  Home: undefined;
  Spark: { matchId: string };
  DateConfirm: { matchId: string };
  Wallet: { matchId: string };
};

const Stack = createNativeStackNavigator<RootStackParamList>();

const RootNavigator = () => {
  const { user, isLoading, isAuthenticated } = useAuth();

  if (isLoading) {
    return null; // Or splash screen
  }

  const isOnboardingComplete = user?.status === 'ACTIVE';

  return (
    <NavigationContainer>
      <Stack.Navigator screenOptions={{ headerShown: false }}>
        {!isAuthenticated ? (
          <>
            <Stack.Screen name="PhoneEntry" component={PhoneEntryScreen} />
            <Stack.Screen name="OtpVerify" component={OtpVerifyScreen} />
          </>
        ) : !isOnboardingComplete ? (
          <>
            <Stack.Screen name="PhoneEntry" component={PhoneEntryScreen} />
            <Stack.Screen name="OtpVerify" component={OtpVerifyScreen} />
          </>
        ) : (
          <>
            <Stack.Screen name="Home" component={HomeScreen} />
            <Stack.Screen name="Spark" component={SparkScreen} />
            <Stack.Screen name="DateConfirm" component={DateConfirmScreen} />
            <Stack.Screen name="Wallet" component={WalletScreen} />
          </>
        )}
      </Stack.Navigator>
    </NavigationContainer>
  );
};

export default RootNavigator;
