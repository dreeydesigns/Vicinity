import React, { createContext, useContext, useState, useCallback } from 'react';

interface ActiveMatch {
  id: string;
  status: string;
  compatibilityScore: number;
  otherUser: {
    id: string;
    displayName: string;
    photos: string[];
    bio?: string;
  };
  venue?: {
    name: string;
    address: string;
    latitude: number;
    longitude: number;
  };
  scheduledAt?: Date;
  expiresAt: Date;
}

interface MatchContextType {
  activeMatches: ActiveMatch[];
  currentMatch: ActiveMatch | null;
  setCurrentMatch: (match: ActiveMatch | null) => void;
  addMatch: (match: ActiveMatch) => void;
  removeMatch: (matchId: string) => void;
  updateMatch: (matchId: string, updates: Partial<ActiveMatch>) => void;
}

const MatchContext = createContext<MatchContextType | undefined>(undefined);

export const MatchProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [activeMatches, setActiveMatches] = useState<ActiveMatch[]>([]);
  const [currentMatch, setCurrentMatch] = useState<ActiveMatch | null>(null);

  const addMatch = useCallback((match: ActiveMatch) => {
    setActiveMatches((prev) => {
      if (prev.find((m) => m.id === match.id)) return prev;
      return [match, ...prev];
    });
    setCurrentMatch(match);
  }, []);

  const removeMatch = useCallback((matchId: string) => {
    setActiveMatches((prev) => prev.filter((m) => m.id !== matchId));
    setCurrentMatch((prev) => (prev?.id === matchId ? null : prev));
  }, []);

  const updateMatch = useCallback((matchId: string, updates: Partial<ActiveMatch>) => {
    setActiveMatches((prev) =>
      prev.map((m) => (m.id === matchId ? { ...m, ...updates } : m))
    );
    setCurrentMatch((prev) =>
      prev?.id === matchId ? { ...prev, ...updates } : prev
    );
  }, []);

  return (
    <MatchContext.Provider
      value={{
        activeMatches,
        currentMatch,
        setCurrentMatch,
        addMatch,
        removeMatch,
        updateMatch,
      }}
    >
      {children}
    </MatchContext.Provider>
  );
};

export const useMatchContext = () => {
  const context = useContext(MatchContext);
  if (!context) throw new Error('useMatchContext must be used within MatchProvider');
  return context;
};
