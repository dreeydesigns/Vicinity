import React, { useEffect, useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  Image,
  TouchableOpacity,
  Animated,
  Dimensions,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useNavigation, useRoute, RouteProp } from '@react-navigation/native';
import { RootStackParamList } from '../../navigation/RootNavigator';
import { useMatchSpark } from '../../hooks/useMatchSpark';
import { useSmartwatch } from '../../hooks/useSmartwatch';
import apiClient from '../../api/client';

type RouteProps = RouteProp<RootStackParamList, 'Spark'>;
const { width } = Dimensions.get('window');

const SparkScreen = () => {
  const navigation = useNavigation();
  const route = useRoute<RouteProps>();
  const { matchId } = route.params;
  const { currentMatch } = useMatchSpark();
  const { sendWatchHaptic } = useSmartwatch();

  const [match, setMatch] = useState(currentMatch);
  const [countdown, setCountdown] = useState(900); // 15 minutes
  const [isLoading, setIsLoading] = useState(false);
  const [slideAnim] = useState(new Animated.Value(width));

  useEffect(() => {
    // Fetch match details if not in context
    if (!match) {
      fetchMatchDetails();
    }

    // Slide in animation
    Animated.timing(slideAnim, {
      toValue: 0,
      duration: 400,
      useNativeDriver: true,
    }).start();

    // Countdown timer
    const timer = setInterval(() => {
      setCountdown((prev) => {
        if (prev <= 1) {
          clearInterval(timer);
          navigation.goBack();
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, [match, navigation, slideAnim]);

  const fetchMatchDetails = async () => {
    try {
      const response = await apiClient.get(`/matches/${matchId}`);
      const matchData = response.data.match;
      const otherUser = matchData.user1Id === matchData.userId ? matchData.user2 : matchData.user1;
      setMatch({
        id: matchData.id,
        status: matchData.status,
        compatibilityScore: matchData.compatibilityScore,
        otherUser: {
          id: otherUser.id,
          displayName: otherUser.profile?.displayName || 'Someone',
          photos: otherUser.profile?.photos || [],
          bio: otherUser.profile?.bio,
        },
        expiresAt: new Date(matchData.expiresAt),
      });
    } catch (error) {
      console.error('Failed to fetch match:', error);
    }
  };

  const handleConsent = async () => {
    setIsLoading(true);
    try {
      const response = await apiClient.post('/matches/consent', { matchId });
      if (response.data.bothConsented) {
        sendWatchHaptic('WALLET_UNLOCK');
        // Navigate to date confirmation
        navigation.navigate('DateConfirm', { matchId });
      } else {
        // Show waiting state
        setMatch((prev) => prev ? { ...prev, status: 'PENDING_SCHEDULE' } : null);
      }
    } catch (error) {
      console.error('Consent failed:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleDecline = () => {
    navigation.goBack();
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  if (!match) {
    return (
      <SafeAreaView style={styles.container}>
        <Text style={styles.loadingText}>Loading match...</Text>
      </SafeAreaView>
    );
  }

  const photoUrl = match.otherUser.photos?.[0];

  return (
    <SafeAreaView style={styles.container}>
      <Animated.View style={[styles.content, { transform: [{ translateX: slideAnim }] }]}>
        {/* Countdown */}
        <View style={styles.countdownContainer}>
          <Text style={styles.countdownLabel}>Match expires in</Text>
          <Text style={styles.countdown}>{formatTime(countdown)}</Text>
        </View>

        {/* Profile Card */}
        <View style={styles.card}>
          {photoUrl ? (
            <Image source={{ uri: photoUrl }} style={styles.photo} />
          ) : (
            <View style={styles.photoPlaceholder}>
              <Text style={styles.placeholderText}>{match.otherUser.displayName[0]}</Text>
            </View>
          )}

          <Text style={styles.name}>{match.otherUser.displayName}</Text>

          <View style={styles.compatibilityBadge}>
            <Text style={styles.compatibilityText}>
              {match.compatibilityScore}% Match
            </Text>
          </View>

          {match.otherUser.bio && (
            <Text style={styles.bio} numberOfLines={3}>
              {match.otherUser.bio}
            </Text>
          )}
        </View>

        {/* Action Buttons */}
        <View style={styles.actions}>
          <TouchableOpacity
            style={[styles.button, styles.declineButton]}
            onPress={handleDecline}
            disabled={isLoading}
          >
            <Text style={styles.declineText}>Not Now</Text>
          </TouchableOpacity>

          <TouchableOpacity
            style={[styles.button, styles.acceptButton]}
            onPress={handleConsent}
            disabled={isLoading}
          >
            <Text style={styles.acceptText}>
              {isLoading ? '...' : "Let's Meet"}
            </Text>
          </TouchableOpacity>
        </View>
      </Animated.View>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#0a0a0a',
  },
  content: {
    flex: 1,
    paddingHorizontal: 24,
    paddingTop: 20,
  },
  loadingText: {
    color: '#fff',
    fontSize: 18,
    textAlign: 'center',
    marginTop: 100,
  },
  countdownContainer: {
    alignItems: 'center',
    marginBottom: 24,
  },
  countdownLabel: {
    fontSize: 14,
    color: '#888',
    marginBottom: 4,
  },
  countdown: {
    fontSize: 36,
    fontWeight: '800',
    color: '#ff6b6b',
  },
  card: {
    backgroundColor: '#1a1a1a',
    borderRadius: 24,
    padding: 24,
    alignItems: 'center',
    marginBottom: 32,
  },
  photo: {
    width: 120,
    height: 120,
    borderRadius: 60,
    marginBottom: 16,
  },
  photoPlaceholder: {
    width: 120,
    height: 120,
    borderRadius: 60,
    backgroundColor: '#ff6b6b',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 16,
  },
  placeholderText: {
    fontSize: 48,
    fontWeight: '800',
    color: '#fff',
  },
  name: {
    fontSize: 28,
    fontWeight: '800',
    color: '#fff',
    marginBottom: 12,
  },
  compatibilityBadge: {
    backgroundColor: '#ff6b6b20',
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 20,
    marginBottom: 16,
  },
  compatibilityText: {
    color: '#ff6b6b',
    fontSize: 16,
    fontWeight: '700',
  },
  bio: {
    fontSize: 14,
    color: '#aaa',
    textAlign: 'center',
    lineHeight: 20,
  },
  actions: {
    flexDirection: 'row',
    gap: 16,
  },
  button: {
    flex: 1,
    height: 56,
    borderRadius: 16,
    justifyContent: 'center',
    alignItems: 'center',
  },
  declineButton: {
    backgroundColor: '#2a2a2a',
  },
  declineText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: '700',
  },
  acceptButton: {
    backgroundColor: '#ff6b6b',
  },
  acceptText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: '700',
  },
});

export default SparkScreen;
