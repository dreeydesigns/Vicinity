import React, { useEffect, useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  ScrollView,
  ActivityIndicator,
  Linking,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useRoute, RouteProp } from '@react-navigation/native';
import { RootStackParamList } from '../../navigation/RootNavigator';
import apiClient from '../../api/client';

type RouteProps = RouteProp<RootStackParamList, 'DateConfirm'>;

interface DateSuggestion {
  id: string;
  venue: {
    placeId: string;
    name: string;
    address: string;
    latitude: number;
    longitude: number;
    rating?: number;
    priceLevel?: number;
    venueType: string;
  };
  timeSlot: {
    start: string;
    end: string;
  };
  rationale: string;
}

const DateConfirmScreen = () => {
  const route = useRoute<RouteProps>();
  const { matchId } = route.params;

  const [suggestions, setSuggestions] = useState<DateSuggestion[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [confirming, setConfirming] = useState(false);

  useEffect(() => {
    fetchSuggestions();
  }, [matchId]);

  const fetchSuggestions = async () => {
    try {
      setIsLoading(true);
      const response = await apiClient.post('/scheduler/suggest', { matchId });
      setSuggestions(response.data.suggestions);
    } catch (error) {
      console.error('Failed to fetch suggestions:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleSelect = async (suggestionId: string) => {
    setSelectedId(suggestionId);
    setConfirming(true);

    try {
      await apiClient.post('/scheduler/select', { matchId, suggestionId });
      // Navigate to wallet or show confirmation
    } catch (error) {
      console.error('Selection failed:', error);
    } finally {
      setConfirming(false);
    }
  };

  const openInMaps = (lat: number, lng: number) => {
    const url = `https://www.google.com/maps/dir/?api=1&destination=${lat},${lng}`;
    Linking.openURL(url);
  };

  const formatTime = (isoString: string) => {
    const date = new Date(isoString);
    return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  };

  if (isLoading) {
    return (
      <SafeAreaView style={styles.container}>
        <ActivityIndicator size="large" color="#ff6b6b" />
        <Text style={styles.loadingText}>Finding the perfect spot...</Text>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.container}>
      <Text style={styles.title}>Pick a Date Spot</Text>
      <Text style={styles.subtitle}>Choose where you'd like to meet</Text>

      <ScrollView style={styles.scroll} showsVerticalScrollIndicator={false}>
        {suggestions.map((suggestion) => (
          <TouchableOpacity
            key={suggestion.id}
            style={[
              styles.card,
              selectedId === suggestion.id && styles.cardSelected,
            ]}
            onPress={() => handleSelect(suggestion.id)}
            disabled={confirming}
          >
            <View style={styles.cardHeader}>
              <Text style={styles.venueName}>{suggestion.venue.name}</Text>
              {suggestion.venue.rating && (
                <View style={styles.ratingBadge}>
                  <Text style={styles.ratingText}>★ {suggestion.venue.rating}</Text>
                </View>
              )}
            </View>

            <Text style={styles.address}>{suggestion.venue.address}</Text>

            <View style={styles.timeRow}>
              <Text style={styles.timeText}>
                {formatTime(suggestion.timeSlot.start)} - {formatTime(suggestion.timeSlot.end)}
              </Text>
              <Text style={styles.typeText}>
                {suggestion.venue.venueType}
              </Text>
            </View>

            <Text style={styles.rationale}>{suggestion.rationale}</Text>

            <TouchableOpacity
              style={styles.mapButton}
              onPress={() => openInMaps(suggestion.venue.latitude, suggestion.venue.longitude)}
            >
              <Text style={styles.mapButtonText}>Open in Maps</Text>
            </TouchableOpacity>
          </TouchableOpacity>
        ))}
      </ScrollView>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#0a0a0a',
    paddingHorizontal: 24,
  },
  title: {
    fontSize: 28,
    fontWeight: '800',
    color: '#fff',
    marginTop: 16,
    marginBottom: 4,
  },
  subtitle: {
    fontSize: 16,
    color: '#888',
    marginBottom: 24,
  },
  scroll: {
    flex: 1,
  },
  card: {
    backgroundColor: '#1a1a1a',
    borderRadius: 20,
    padding: 20,
    marginBottom: 16,
    borderWidth: 2,
    borderColor: 'transparent',
  },
  cardSelected: {
    borderColor: '#ff6b6b',
  },
  cardHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 8,
  },
  venueName: {
    fontSize: 20,
    fontWeight: '700',
    color: '#fff',
    flex: 1,
  },
  ratingBadge: {
    backgroundColor: '#ff6b6b20',
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: 12,
  },
  ratingText: {
    color: '#ff6b6b',
    fontSize: 14,
    fontWeight: '700',
  },
  address: {
    fontSize: 14,
    color: '#888',
    marginBottom: 12,
  },
  timeRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 8,
  },
  timeText: {
    fontSize: 14,
    color: '#fff',
    fontWeight: '600',
  },
  typeText: {
    fontSize: 12,
    color: '#ff6b6b',
    textTransform: 'uppercase',
    fontWeight: '700',
  },
  rationale: {
    fontSize: 13,
    color: '#aaa',
    fontStyle: 'italic',
    marginBottom: 12,
  },
  mapButton: {
    backgroundColor: '#2a2a2a',
    paddingVertical: 10,
    borderRadius: 12,
    alignItems: 'center',
  },
  mapButtonText: {
    color: '#fff',
    fontSize: 14,
    fontWeight: '600',
  },
  loadingText: {
    color: '#888',
    fontSize: 16,
    textAlign: 'center',
    marginTop: 16,
  },
});

export default DateConfirmScreen;
