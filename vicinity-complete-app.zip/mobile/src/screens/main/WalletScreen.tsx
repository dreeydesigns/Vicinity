import React, { useEffect, useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Linking,
  ActivityIndicator,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useRoute, RouteProp } from '@react-navigation/native';
import { RootStackParamList } from '../../navigation/RootNavigator';
import { useEncryption } from '../../hooks/useEncryption';
import apiClient from '../../api/client';

type RouteProps = RouteProp<RootStackParamList, 'Wallet'>;

interface WalletData {
  status: string;
  phoneNumber?: string;
  email?: string;
  instagram?: string;
  telegram?: string;
  bioSnippet?: string;
  displayName?: string;
}

const WalletScreen = () => {
  const route = useRoute<RouteProps>();
  const { matchId } = route.params;
  const { generateECDHKeyPair, decrypt } = useEncryption();

  const [wallet, setWallet] = useState<WalletData | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isLocked, setIsLocked] = useState(true);

  useEffect(() => {
    fetchWallet();
  }, [matchId]);

  const fetchWallet = async () => {
    try {
      setIsLoading(true);
      const response = await apiClient.get(`/wallet/${matchId}`);
      const data = response.data;

      if (data.status === 'unlocked') {
        setIsLocked(false);
        // Decrypt wallet data
        const keyPair = await generateECDHKeyPair();
        await apiClient.post('/wallet/exchange', {
          matchId,
          userPublicKey: keyPair.publicKey,
        });

        // In production, decrypt client-side with shared secret
        // For MVP, server returns decrypted data after exchange
        setWallet(data);
      } else {
        setIsLocked(true);
      }
    } catch (error) {
      console.error('Wallet fetch error:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleUnlock = async () => {
    try {
      setIsLoading(true);
      const keyPair = await generateECDHKeyPair();
      await apiClient.post('/wallet/exchange', {
        matchId,
        userPublicKey: keyPair.publicKey,
      });
      await fetchWallet();
    } catch (error) {
      console.error('Unlock failed:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleCall = (phoneNumber: string) => {
    Linking.openURL(`tel:${phoneNumber}`);
  };

  const handleEmail = (email: string) => {
    Linking.openURL(`mailto:${email}`);
  };

  if (isLoading) {
    return (
      <SafeAreaView style={styles.container}>
        <ActivityIndicator size="large" color="#ff6b6b" />
      </SafeAreaView>
    );
  }

  if (isLocked) {
    return (
      <SafeAreaView style={styles.container}>
        <View style={styles.lockedContainer}>
          <Text style={styles.lockIcon}>🔒</Text>
          <Text style={styles.lockedTitle}>Match Wallet Locked</Text>
          <Text style={styles.lockedText}>
            Both of you need to agree to share contact details before the wallet unlocks.
          </Text>
          <TouchableOpacity style={styles.unlockButton} onPress={handleUnlock}>
            <Text style={styles.unlockText}>Request Unlock</Text>
          </TouchableOpacity>
        </View>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.container}>
      <Text style={styles.title}>Match Wallet</Text>
      <Text style={styles.subtitle}>Contact details shared after mutual consent</Text>

      <View style={styles.card}>
        {wallet?.displayName && (
          <View style={styles.field}>
            <Text style={styles.label}>Name</Text>
            <Text style={styles.value}>{wallet.displayName}</Text>
          </View>
        )}

        {wallet?.phoneNumber && (
          <TouchableOpacity
            style={styles.field}
            onPress={() => handleCall(wallet.phoneNumber!)}
          >
            <Text style={styles.label}>Phone</Text>
            <Text style={[styles.value, styles.link]}>{wallet.phoneNumber}</Text>
          </TouchableOpacity>
        )}

        {wallet?.email && (
          <TouchableOpacity
            style={styles.field}
            onPress={() => handleEmail(wallet.email!)}
          >
            <Text style={styles.label}>Email</Text>
            <Text style={[styles.value, styles.link]}>{wallet.email}</Text>
          </TouchableOpacity>
        )}

        {wallet?.instagram && (
          <View style={styles.field}>
            <Text style={styles.label}>Instagram</Text>
            <Text style={styles.value}>@{wallet.instagram}</Text>
          </View>
        )}

        {wallet?.telegram && (
          <View style={styles.field}>
            <Text style={styles.label}>Telegram</Text>
            <Text style={styles.value}>@{wallet.telegram}</Text>
          </View>
        )}

        {wallet?.bioSnippet && (
          <View style={styles.field}>
            <Text style={styles.label}>Bio</Text>
            <Text style={styles.value}>{wallet.bioSnippet}</Text>
          </View>
        )}
      </View>

      <Text style={styles.disclaimer}>
        These details are shared securely and encrypted. Be respectful and stay safe.
      </Text>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#0a0a0a',
    paddingHorizontal: 24,
  },
  title: {
    fontSize: 28,
    fontWeight: '800',
    color: '#fff',
    marginTop: 16,
    marginBottom: 4,
  },
  subtitle: {
    fontSize: 14,
    color: '#888',
    marginBottom: 24,
  },
  lockedContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    paddingHorizontal: 32,
  },
  lockIcon: {
    fontSize: 64,
    marginBottom: 16,
  },
  lockedTitle: {
    fontSize: 24,
    fontWeight: '800',
    color: '#fff',
    marginBottom: 8,
  },
  lockedText: {
    fontSize: 14,
    color: '#888',
    textAlign: 'center',
    lineHeight: 20,
    marginBottom: 24,
  },
  unlockButton: {
    backgroundColor: '#ff6b6b',
    paddingHorizontal: 32,
    paddingVertical: 14,
    borderRadius: 16,
  },
  unlockText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: '700',
  },
  card: {
    backgroundColor: '#1a1a1a',
    borderRadius: 20,
    padding: 24,
  },
  field: {
    marginBottom: 20,
    borderBottomWidth: 1,
    borderBottomColor: '#2a2a2a',
    paddingBottom: 16,
  },
  label: {
    fontSize: 12,
    color: '#888',
    textTransform: 'uppercase',
    letterSpacing: 1,
    marginBottom: 4,
  },
  value: {
    fontSize: 18,
    color: '#fff',
    fontWeight: '600',
  },
  link: {
    color: '#ff6b6b',
  },
  disclaimer: {
    fontSize: 12,
    color: '#555',
    textAlign: 'center',
    marginTop: 24,
    lineHeight: 18,
  },
});

export default WalletScreen;
