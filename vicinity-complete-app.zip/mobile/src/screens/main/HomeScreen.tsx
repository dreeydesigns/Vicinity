import React, { useEffect, useState, useCallback } from 'react';
import {
  View,
  Text,
  StyleSheet,
  Animated,
  TouchableOpacity,
  Dimensions,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useNavigation } from '@react-navigation/native';
import { NativeStackNavigationProp } from '@react-navigation/native-stack';
import { RootStackParamList } from '../../navigation/RootNavigator';
import { useAuth } from '../../context/AuthContext';
import { useLocation } from '../../hooks/useLocation';
import { useBleProximity } from '../../hooks/useBleProximity';
import { useSmartwatch } from '../../hooks/useSmartwatch';
import { useMatchSpark } from '../../hooks/useMatchSpark';
import apiClient from '../../api/client';

type NavigationProp = NativeStackNavigationProp<RootStackParamList>;
const { width } = Dimensions.get('window');

const HomeScreen = () => {
  const navigation = useNavigation<NavigationProp>();
  const { user, logout } = useAuth();
  const { location, startTracking } = useLocation();
  const { getDiscoveredDevices } = useBleProximity(true);
  const { triggerPhoneVibration } = useSmartwatch();
  const { currentMatch } = useMatchSpark();

  const [pulseAnim] = useState(new Animated.Value(1));
  const [isActive, setIsActive] = useState(false);

  // Start location tracking on mount
  useEffect(() => {
    startTracking();
  }, [startTracking]);

  // Report location + BLE to server periodically
  useEffect(() => {
    if (!location || !isActive) return;

    const interval = setInterval(async () => {
      try {
        const bleDevices = getDiscoveredDevices();
        const bleDeviceIds = bleDevices.map((d) => d.deviceId);
        const bleRssi: Record<string, number> = {};
        bleDevices.forEach((d) => {
          bleRssi[d.deviceId] = d.rssi;
        });

        await apiClient.post('/proximity/report', {
          longitude: location.longitude,
          latitude: location.latitude,
          accuracy: location.accuracy,
          bleDeviceIds,
          bleRssi,
        });
      } catch (error) {
        console.error('Location report error:', error);
      }
    }, 10000); // Every 10 seconds

    return () => clearInterval(interval);
  }, [location, isActive, getDiscoveredDevices]);

  // Pulse animation
  useEffect(() => {
    if (!isActive) return;

    const pulse = Animated.loop(
      Animated.sequence([
        Animated.timing(pulseAnim, {
          toValue: 1.5,
          duration: 1500,
          useNativeDriver: true,
        }),
        Animated.timing(pulseAnim, {
          toValue: 1,
          duration: 1500,
          useNativeDriver: true,
        }),
      ])
    );
    pulse.start();
    return () => pulse.stop();
  }, [isActive, pulseAnim]);

  // Navigate to spark when match detected
  useEffect(() => {
    if (currentMatch) {
      triggerPhoneVibration('MATCH_BUZZ');
      navigation.navigate('Spark', { matchId: currentMatch.id });
    }
  }, [currentMatch, navigation, triggerPhoneVibration]);

  const toggleActive = useCallback(() => {
    setIsActive((prev) => !prev);
  }, []);

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.greeting}>Hello, {user?.profile?.displayName || 'there'}</Text>
        <TouchableOpacity onPress={logout}>
          <Text style={styles.logout}>Logout</Text>
        </TouchableOpacity>
      </View>

      <View style={styles.center}>
        <TouchableOpacity onPress={toggleActive} activeOpacity={0.8}>
          <View style={styles.pulseContainer}>
            {isActive && (
              <Animated.View
                style={[
                  styles.pulseRing,
                  {
                    transform: [{ scale: pulseAnim }],
                    opacity: pulseAnim.interpolate({
                      inputRange: [1, 1.5],
                      outputRange: [0.6, 0],
                    }),
                  },
                ]}
              />
            )}
            <View style={[styles.core, isActive && styles.coreActive]}>
              <Text style={styles.coreText}>
                {isActive ? 'Searching...' : 'Tap to Start'}
              </Text>
            </View>
          </View>
        </TouchableOpacity>

        {location && (
          <Text style={styles.locationText}>
            Location active • {location.latitude.toFixed(4)}, {location.longitude.toFixed(4)}
          </Text>
        )}
      </View>

      <View style={styles.footer}>
        <Text style={styles.footerText}>
          {isActive
            ? 'Vicinity is scanning for compatible matches nearby'
            : 'Activate to find matches within 500 meters'}
        </Text>
      </View>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#0a0a0a',
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 24,
    paddingTop: 16,
  },
  greeting: {
    fontSize: 20,
    fontWeight: '700',
    color: '#fff',
  },
  logout: {
    fontSize: 14,
    color: '#ff6b6b',
  },
  center: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  pulseContainer: {
    width: 200,
    height: 200,
    justifyContent: 'center',
    alignItems: 'center',
  },
  pulseRing: {
    position: 'absolute',
    width: 200,
    height: 200,
    borderRadius: 100,
    backgroundColor: '#ff6b6b',
  },
  core: {
    width: 140,
    height: 140,
    borderRadius: 70,
    backgroundColor: '#1a1a1a',
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 3,
    borderColor: '#333',
  },
  coreActive: {
    borderColor: '#ff6b6b',
    backgroundColor: '#ff6b6b20',
  },
  coreText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: '700',
    textAlign: 'center',
  },
  locationText: {
    marginTop: 24,
    fontSize: 12,
    color: '#555',
  },
  footer: {
    paddingHorizontal: 32,
    paddingBottom: 40,
  },
  footerText: {
    fontSize: 14,
    color: '#666',
    textAlign: 'center',
    lineHeight: 20,
  },
});

export default HomeScreen;
